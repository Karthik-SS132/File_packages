generate_service_coupon = {
	constructScreen : function () {
		$("#generate_service_coupon_header_1").attr("style", "height: 90%; width: 100%;").html("<div style='height:100%;width:100%'>" +"<div id='generate_service_coupon_preview' style='width:573px;height:530px;'></div>" +"</div>");
		$("#generate_service_coupon_preview").initializeWPdfviewer({screenID: "generate_service_coupon",source: login_profile.protocol + "//" + login_profile.domain_name + ((login_profile.portno === "") ? ("") : (":" + login_profile.portno)) + "/" + generate_service_coupon.variable.custom.output_file_path + generate_service_coupon.variable.custom.document_type + "/" + generate_service_coupon.variable.custom.output_file_name.replace(/\//g, "-") + ".pdf"+ "?state=" + new Date().getTime()
		});
	},
	variable : {
		standard : {
			popupIndicator : true
		},
		custom : {
			
		}
	}
};
