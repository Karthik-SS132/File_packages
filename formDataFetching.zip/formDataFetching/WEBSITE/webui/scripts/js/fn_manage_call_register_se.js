var manage_call_register_se = {
	constructScreen : function () {
		manage_call_register_se.variable.custom.datasource_1 = mserviceUtilities.getTransportPagingDataSource({
				applicationName : "mservice",
				serviceName : "retrieve_manage_call_register",
				outputPath : "context/outputparam_detail",
				pageSize : 50,
				inputParameter : {
					p_inputparam_xml : "manage_call_register_se.customRequirementHandler.getFilterValues()"
				},
				schemaModel : true,
				screenID : "manage_call_register_se",
				dataSourceName : "datasource_1",
				processResponse : true,
				serverPaging : true
			});
		manage_call_register_se.variable.custom.datasource_2 = mserviceUtilities.getTransportDataSource({
				applicationName : "common_modules",
				serviceName : "retrieve_listof_values_for_searchcondition",
				outputPath : "context/outputparam",
				pageSize : 10,
				inputParameter : {
					p_inputparam_xml : "<inputparam><lov_code_type>'COMP_FEATURE_ACCESS_AUTH_LIST'</lov_code_type></inputparam>"
				},
				screenID : "manage_call_register_se",
			});
		if (login_profile.user_group_type == "CU") {
			manage_call_register_se.variable.custom.customerUserDetails = mserviceUtilities.getTransportDataSource({
					applicationName : "common_modules",
					serviceName : "retrieve_listof_values",
					inputParameter : {
						p_lov_code : "'GET_CUST_USER_DETAILS'",
						p_search_field_1 : "$login_profile.user_id",
						p_search_field_2 : "",
						p_search_field_3 : "",
						p_search_field_4 : "",
						p_search_field_5 : ""
					}
				});
			manage_call_register_se.variable.custom.customerUserDetails.read();
			if (manage_call_register_se.variable.custom.customerUserDetails.data()[0] != undefined) {
				manage_call_register_se.variable.custom.customerUserCustomerID = manage_call_register_se.variable.custom.customerUserDetails.data()[0].p_value_field_1;
			}
		}
	},
	postConstruct : function () {
		manage_call_register_se_filterArea = $("#manage_call_register_se_pane2");
		$("#manage_call_register_se_content_1 span dt").removeClass("term_one");
		$("#manage_call_register_se_content_1 span dd.colen").html("");
		$("#manage_call_register_se_content_1").find('dt').css("width","120px");
		$("#manage_call_register_se_editor").append("<li id='manage_call_register_se_grid_pager'></li>");
		$("#manage_call_register_se_grid_pager").append($("#manage_call_register_se_grid_1").find(".k-grid-pager")).css("width","350px").css("float","right").children().css("border-top-width","0px");
		$("#manage_call_register_se_grid_1").data("kendoGrid").bind("dataBound", manage_call_register_se.customRequirementHandler.gridPager);
		if(manage_call_register_se.variable.custom.autoLoadInd == "true") {
			manage_call_register_se.variable.custom.grid_1.dataSource.pageSize(50);
		}
		setTimeout(function(){
			manage_call_register_se_splitter[manage_call_register_se_filterArea.width() > 0 ? "collapse" : "expand"](manage_call_register_se_filterArea);
			$("#" + screenID).delegate(webWidgetInitializer.variable.widgetSelector, "change", function () {
				mserviceUtilities.resetFilterIndicator({
					contentID : "manage_call_register_se_content_1",
					screenID : "manage_call_register_se",
					matchCondition : ["_filter"]
				});
			});
			mserviceUtilities.resetFilterIndicator({
				contentID : "manage_call_register_se_content_1",
				screenID : "manage_call_register_se",
				matchCondition : ["_filter"]
			});
		}, 30);
	},
	initializeWidgets : function () {
		manage_call_register_se.variable.custom.grid_1 = $("#manage_call_register_se_grid_1").initializeWGrid({
				screenID : "manage_call_register_se",
				dataSource : manage_call_register_se.variable.custom.datasource_1,
				height : 500,
				pageSize : 50,
				filterable : false,
				sortable : true,
				pageable : false,
				toolbar : false
			});
		$("#manage_call_register_se_contextMenu").kendoContextMenu({
			orientation: "vertical",
			target: "[data-widget-type = 'w_link'][data-link-type = 'actions']",
		});
		$("#manage_call_register_se_editor").kendoMenu();		
		manage_call_register_se_splitter = $("#manage_call_register_se_splitter").kendoSplitter({
			panes: [
				{ collapsible: true, size: 330 ,resizable: false },
				{ }
			],
			resize: function(e) {
				manage_call_register_se.customRequirementHandler.gridPager();
			}
		}).data("kendoSplitter");
	},
	refreshScreen : function () {
		manage_call_register_se.variable.custom.grid_1.dataSource.pageSize(50);
	},
	buttonEventHandler : {
		crud_btn_click : function (element, event) {
			if (manage_call_register_se.variable.custom.crudIndicator == "R") {
				manage_call_register_se.variable.custom.grid_1.dataSource._skip = 0;
				manage_call_register_se.variable.custom.grid_1.dataSource.pageSize(50);
			} else {
				if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_manage_call_register_se_edit.js", "../../s_iscripts/save_manage_call_register.js"])) {
					webNavigationController.gotoNextScreen({
						screenID : "manage_call_register_se",
						nextScreenID : "manage_call_register_se_edit",
						nextScreenName : manage_call_register_se.variable.custom.nextScreenName
					});
				} else {
					alert("Sorry. This feature is unavailable. Please contact your support desk.");
					return false;
				}
			}
		},
		misc_btn_click : function (element, event){
			if(manage_call_register_se.variable.custom.miscID == "filters"){
				manage_call_register_se_splitter[manage_call_register_se_filterArea.width() > 0 ? "collapse" : "expand"](manage_call_register_se_filterArea);
			}
			if(manage_call_register_se.variable.custom.miscID == "clear_filters"){
				mserviceUtilities.resetInputparamXML({
					contentID : "manage_call_register_se_content_1",
					screenID : "manage_call_register_se",
					matchCondition : ["_filter"]
				});
			}
			if(manage_call_register_se.variable.custom.miscID == "field_failure_report"){
				if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_form_handler.js"])) {
					my_calls = {
						variable : {
							selectedRecord : {}
						}
					};
					manage_call_register_se.variable.custom.myCallData = mserviceUtilities.getTransportPagingDataSource({
						applicationName : "common_modules",
						serviceName : "retrieve_manage_custom_info_list",
						outputPath : "outputparam_detail",
						api : true,
						pageSize : 50,
						inputParameter : {
							p_custom_info_code : "'retrieve_my_calls'",
							p_inputparam_xml : "'<inputparam><assigned_to_emp_id_filter>" + login_profile.emp_id +"</assigned_to_emp_id_filter><call_ref_no_filter>" + manage_call_register_se.variable.custom.selectedRecord.call_no + "</call_ref_no_filter></inputparam>'"
						},
						screenID : "manage_call_register_se"
					});
					manage_call_register_se.variable.custom.myCallData.read();
					if(manage_call_register_se.variable.custom.myCallData.data().length != 0){
						my_calls.variable.selectedRecord = manage_call_register_se.variable.custom.myCallData.data()[0];
					};
					form_handler.variable.template = manage_call_register_se.variable.custom.miscID;
					form_handler.variable.transNo = manage_call_register_se.variable.custom.selectedRecord.call_no;
					form_handler.variable.attachInd = "C";
					form_handler.variable.taskID = "0";
					$("#manage_call_register_se_grid_1").append("<div id = 'manage_call_register_se_form_handler_window'><div id = 'manage_call_register_se_form_handler_loader' style='width: 100%; height: 90%;' ></div></div>");
					$("#manage_call_register_se_form_handler_window").kendoWindow({
						width : (screen.width * 0.30),
						height : (screen.height * 0.75),
						title : manage_call_register_se.variable.custom.nextScreenName,
						visible : false,
						modal : true,
						deactivate : function () {
							eval("delete form_handler");
							eval("delete formHandlerRuleEngine");
							this.destroy();
						},
					});
					$.ajax({
						url : mserviceUtilities.getWebserverpath() + "webui/html/form_handler.html",
						async : false,
						dataType : "text",
						cache : true
					}).done(function (data) {
						try {
							$("#manage_call_register_se_form_handler_loader").append(data);
							form_handler.constructScreen();
							$("#manage_call_register_se_form_handler_window").data("kendoWindow").center().open();
							manage_call_register_se.customRequirementHandler.formValueAssignment();
							formHandlerRuleEngine.executeRuleStatements({
								screenID : "form_handler_" + form_handler.variable.template,
								objectID : "screen",
								eventID : "load",
								fieldID : "form_handler_" + form_handler.variable.template
							});
							$(".k-overlay").css("opacity", "0.8");
						} catch (ex) {
							alert("Sorry. This feature is unavailable. Please contact your support desk.");
							eval("delete form_handler");
							eval("delete formHandlerRuleEngine");
							$("#manage_call_register_se_form_handler_window").data("kendoWindow").destroy();
							return false;
						}
					});
				} else {
					alert("Sorry. This feature is unavailable. Please contact your support desk.");
					return false;
				}
			}
			$("#manage_call_register_se_filters_btn .k-i-filter").css("color","black");
		},		
		feature_btn_click : function (element, event) {
			if (manage_call_register_se.variable.custom.selectedFeatureID == "manage_user_attachments") {
				if (manage_call_register_se.variable.custom.grid_1.select().length != 0) {
					if (manage_call_register_se.customRequirementHandler.validateAccess(element)) {
						if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_manage_user_attachments.js"])) {
							manage_user_attachments.variable.standard.configurationParam = "CALL";
							manage_user_attachments.variable.custom.project_task_level_ind = "C";
							manage_user_attachments.variable.custom.project_id = manage_call_register_se.variable.custom.selectedRecord.call_no;
							manage_user_attachments.variable.custom.template_id = "";
							manage_user_attachments.variable.custom.task_id = "0";
							manage_user_attachments.variable.custom.project_status_defaultValue = manage_call_register_se.variable.custom.selectedRecord.call_status_desc;
							webNavigationController.gotoNextScreen({
								screenID : "manage_call_register_se",
								nextScreenID : "manage_user_attachments",
								nextScreenName : "Attachments"
							});
						} else {
							alert("Sorry. This feature is unavailable. Please contact support desk.");
							return false;
						}
					} else {
						alert("You do not have access to this call.");
						return false;
					}
				} else {
					alert("No row has been selected.");
					return false;
				}
			} else if (manage_call_register_se.variable.custom.selectedFeatureID == "view_calendar") {
				if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_view_calendar.js", "../../s_iscripts/retrieve_calendar.js"])) {
					displayLabel = 'Calendar';
					$.get('view_calendar.html', function (data) {
						$("#manage_call_register_se").hide();
						$("#container").append(data);
						fn_view_calendar();
					});
				} else {
					alert("Sorry. This feature is unavailable. Please contact support desk.");
					return false;
				}
			} else if (manage_call_register_se.variable.custom.selectedFeatureID == "manage_call_resource_update") {
				if (manage_call_register_se.variable.custom.grid_1.select().length != 0) {
					if (manage_call_register_se.customRequirementHandler.validateAccess(element)) {
						if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_manage_call_resource_update.js", "../../s_iscripts/update_project_resourcelist_detail.js"])) {
							webNavigationController.gotoNextScreen({
								screenID : "manage_call_register_se",
								nextScreenID : "manage_call_resource_update",
								nextScreenName : "Resource Update"
							});
						} else {
							alert("Sorry. This feature is unavailable. Please contact support desk.");
							return false;
						}
					} else {
						alert("You do not have access to this call.");
						return false;
					}
				} else {
					alert("No row has been selected");
					return false;
				}
			} else if (manage_call_register_se.variable.custom.selectedFeatureID == "manage_call_sparepart_update") {
				if (manage_call_register_se.variable.custom.grid_1.select().length != 0) {
					if (manage_call_register_se.customRequirementHandler.validateAccess(element)) {
						if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_manage_call_sparepart_update.js", "../../s_iscripts/update_inventory_consumption.js"])) {
							webNavigationController.gotoNextScreen({
								screenID : "manage_call_register_se",
								nextScreenID : "manage_call_sparepart_update",
								nextScreenName : "Sparepart Update"
							});
						} else {
							alert("Sorry. This feature is unavailable. Please contact support desk.");
							return false;
						}
					} else {
						alert("You do not have access to this call.");
						return false;
					}
				} else {
					alert("No row has been selected");
					return false;
				}
			} else if (manage_call_register_se.variable.custom.selectedFeatureID == "track_employee_geolocation") {
				if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_track_employee_geolocation.js"])) {
					webNavigationController.gotoNextScreen({
						screenID : "manage_call_register_se",
						nextScreenID : "track_employee_geolocation",
						nextScreenName : "Track Employee Geolocation"
					});
				} else {
					alert("Sorry. This feature is unavailable. Please contact support desk.");
					return false;
				}
			} else if (manage_call_register_se.variable.custom.selectedFeatureID == "generate_service_coupon") {
				if (manage_call_register_se.variable.custom.grid_1.select().length != 0) {
					if (manage_call_register_se.customRequirementHandler.validateAccess(element)) {
						manage_call_register_se.variable.custom.selectedRecord = manage_call_register_se.variable.custom.grid_1.dataSource.getByUid(manage_call_register_se.variable.custom.grid_1.select().data("uid"));
						if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_generate_service_coupon.js"])) {
							manage_call_register_se.variable.custom.visit_template_id = mserviceUtilities.getTransportDataSource({
									applicationName : "common_modules",
									serviceName : "retrieve_listof_values_for_searchcondition",
									inputParameter : {
										p_inputparam_xml : "'<inputparam><lov_code_type>VISITTEMPLATEID</lov_code_type><search_field_1>" + manage_call_register_se.variable.custom.selectedRecord.call_no + "</search_field_1></inputparam>'"
									},
								});
							manage_call_register_se.variable.custom.visit_template_id.read();
							if (manage_call_register_se.variable.custom.visit_template_id.data().length != 0) {
								generate_service_coupon.variable.custom.document_type = "AssetServiceVisitSchedule";
								generate_service_coupon.variable.custom.document_template = manage_call_register_se.variable.custom.visit_template_id.data()[0].visittemplateid,
								generate_service_coupon.variable.custom.retrieve_service_name = "/mservice/retrieve_asset_service_visit_schedule_for_docgen";
								generate_service_coupon.variable.custom.retrieve_service_inputparam = "<inputparam>";
								generate_service_coupon.variable.custom.retrieve_service_inputparam += "<p_inputparam_xml>";
								generate_service_coupon.variable.custom.retrieve_service_inputparam += getXmlString("<call_no>" + manage_call_register_se.variable.custom.selectedRecord.call_no + "</call_no>");
								generate_service_coupon.variable.custom.retrieve_service_inputparam += getXmlString("<asset_id>" + manage_call_register_se.variable.custom.selectedRecord.asset_id + "</asset_id>");
								generate_service_coupon.variable.custom.retrieve_service_inputparam += "</p_inputparam_xml>";
								generate_service_coupon.variable.custom.retrieve_service_inputparam += "</inputparam>";
								generate_service_coupon.variable.custom.output_file_path = "/content_store/" + login_profile.client_id + "/" + login_profile.country_code + "/";
								generate_service_coupon.variable.custom.output_file_name = manage_call_register_se.variable.custom.visit_template_id.data()[0].visitreportno;
								generate_service_coupon.variable.custom.generate_pdf_document_dataSource_1 = mserviceUtilities.getTransportDataSource({
										applicationName : "common_modules",
										serviceName : "generate_pdf_document",
										outputPath : "context/outputparam_header",
										inputParameter : {
											p_document_type : "$generate_service_coupon.variable.custom.document_type",
											p_document_template : "$generate_service_coupon.variable.custom.document_template",
											p_data_retrieve_service_name : "$generate_service_coupon.variable.custom.retrieve_service_name",
											p_data_retrieve_request_xml : "'" + generate_service_coupon.variable.custom.retrieve_service_inputparam + "'",
											p_output_file_path : "$generate_service_coupon.variable.custom.output_file_path",
											p_output_file_name : "$generate_service_coupon.variable.custom.output_file_name"
										}
									});
								generate_service_coupon.variable.custom.generate_pdf_document_dataSource_1.read();
								if (generate_service_coupon.variable.custom.generate_pdf_document_dataSource_1.data()[0].p_update_status == "SP001") {
									webNavigationController.gotoNextScreen({
										screenID : "manage_call_register_se",
										fieldID : "manage_call_register_se_child_window",
										nextScreenID : "generate_service_coupon",
										nextScreenName : manage_call_register_se.variable.custom.nextScreenName,
										windowHeight : 600,
										windowWidth : 900,
										execute : generate_service_coupon.constructScreen
									});
								} else {
									alert("Sorry. PDF generation failed. Please contact support desk.");
									return false;
								}
							} else {
								alert("Sorry, Service visit is not linked to this call.")
							}
						} else {
							alert("Sorry. This feature is unavailable. Please contact support desk.");
							return false;
						}
					} else {
						alert("You do not have access to this call.");
						return false;
					}
				} else {
					alert("No row has been selected.");
					return false;
				}
			} else if (manage_call_register_se.variable.custom.selectedFeatureID == "generate_expense_document") {
				if (manage_call_register_se.variable.custom.grid_1.select().length != 0) {
					if (manage_call_register_se.customRequirementHandler.validateAccess(element)) {
						manage_call_register_se.variable.custom.selectedRecord = manage_call_register_se.variable.custom.grid_1.dataSource.getByUid(manage_call_register_se.variable.custom.grid_1.select().data("uid"));
						if (mserviceUtilities.loadJSScripts(["../../s_iscripts/generate_expense_document.js"])) {
							if (confirm("Are you sure do you want to generate expense document for this call ?")) {
								var returnValue;
								returnValue = executeService_generate_expense_document({
										p_call_jo_project_ind : "C",
										p_call_jo_project_ref_no : manage_call_register_se.variable.custom.selectedRecord.call_no
									});
								if (returnValue.update_status == "SP001") {
									alert("Expense Document generated successfully. Your Expense Document reference number is " + returnValue.expense_doc_ref_no);
					                manage_call_register_se.variable.custom.grid_1.dataSource.pageSize(50);
									return true;
								} else {
									alert("Generation of Expense Document failed.");
									return false;
								}
							}
						} else {
							alert("Sorry. This feature is unavailable. Please contact support desk.");
							return false;
						}
					} else {
						alert("You do not have access to this call.");
						return false;
					}
				} else {
					alert("No row has been selected.");
					return false;
				}
			} else if (manage_call_register_se.variable.custom.selectedFeatureID == "manage_call_stockout") {
				if (manage_call_register_se.variable.custom.grid_1.select().length != 0) {
					if (manage_call_register_se.customRequirementHandler.validateAccess(element)) {
						if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_manage_call_stockout.js", "../../s_iscripts/update_call_wfeventverb_status_change.js"])) {
							var allowedWorkflowArray;
							manage_call_register_se.variable.custom.selectedRecord = manage_call_register_se.variable.custom.grid_1.dataSource.getByUid(manage_call_register_se.variable.custom.grid_1.select().data("uid"));
							allowedWorkflowArray = mserviceUtilities.getWorkflowEventVerbs({
									eventVerb : "MATLISSUE",
									requestCategory : manage_call_register_se.variable.custom.selectedRecord.call_category,
									requestType : manage_call_register_se.variable.custom.selectedRecord.call_type,
									fromStage : manage_call_register_se.variable.custom.selectedRecord.workflow_stage_no,
									fromStatus : manage_call_register_se.variable.custom.selectedRecord.call_status
								});
							manage_call_register_se.variable.custom.selectedWorkflowToStage = "";
							manage_call_register_se.variable.custom.selectedWorkflowToStatus = "";
							if (allowedWorkflowArray.length != 0) {
								manage_call_register_se.variable.custom.selectedWorkflowToStage = allowedWorkflowArray[0].to_workflow_stage;
								manage_call_register_se.variable.custom.selectedWorkflowToStatus = allowedWorkflowArray[0].to_status;
								manage_call_register_se.variable.custom.selectedCallLoggedDate = mserviceUtilities.getDateObject({
										dateString : manage_call_register_se.variable.custom.selectedRecord.created_on_date,
										hourString : manage_call_register_se.variable.custom.selectedRecord.created_on_hour,
										minuteString : manage_call_register_se.variable.custom.selectedRecord.created_on_minute
									});
								manage_call_register_se.variable.custom.selectedActualStartDate = mserviceUtilities.getDateObject({
										dateString : manage_call_register_se.variable.custom.selectedRecord.act_start_on_date,
										hourString : manage_call_register_se.variable.custom.selectedRecord.act_start_on_hour,
										minuteString : manage_call_register_se.variable.custom.selectedRecord.act_start_on_minute
									});
								manage_call_register_se.variable.custom.selectedScheduledStartDate = mserviceUtilities.getDateObject({
										dateString : manage_call_register_se.variable.custom.selectedRecord.sch_start_on_date,
										hourString : manage_call_register_se.variable.custom.selectedRecord.sch_start_on_hour,
										minuteString : manage_call_register_se.variable.custom.selectedRecord.sch_start_on_minute
									});
								manage_call_register_se.variable.custom.selectedScheduledFinishDate = mserviceUtilities.getDateObject({
										dateString : manage_call_register_se.variable.custom.selectedRecord.sch_finish_on_date,
										hourString : manage_call_register_se.variable.custom.selectedRecord.sch_finish_on_hour,
										minuteString : manage_call_register_se.variable.custom.selectedRecord.sch_finish_on_minute
									});
								webNavigationController.gotoNextScreen({
									screenID : "manage_call_register_se",
									nextScreenID : "manage_call_stockout",
									nextScreenName : "Stockout Update"
								});
							} else {
								alert("Sorry. This feature is unavailable for the selected record.");
								return false;
							}
						} else {
							alert("Sorry. This feature is unavailable. Please contact support desk.");
							return false;
						}
					} else {
						alert("You do not have access to this call.");
						return false;
					}
				} else {
					alert("No row has been selected");
					return false;
				}
			} else if (manage_call_register_se.variable.custom.selectedFeatureID == "manage_call_stockin") {
				if (manage_call_register_se.variable.custom.grid_1.select().length != 0) {
					if (manage_call_register_se.customRequirementHandler.validateAccess(element)) {
						if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_manage_call_stockin.js", "../../s_iscripts/update_call_wfeventverb_status_change.js"])) {
							var allowedWorkflowArray;
							manage_call_register_se.variable.custom.selectedRecord = manage_call_register_se.variable.custom.grid_1.dataSource.getByUid(manage_call_register_se.variable.custom.grid_1.select().data("uid"));
							allowedWorkflowArray = mserviceUtilities.getWorkflowEventVerbs({
									eventVerb : "MATLRECEIPT",
									requestCategory : manage_call_register_se.variable.custom.selectedRecord.call_category,
									requestType : manage_call_register_se.variable.custom.selectedRecord.call_type,
									fromStage : manage_call_register_se.variable.custom.selectedRecord.workflow_stage_no,
									fromStatus : manage_call_register_se.variable.custom.selectedRecord.call_status
								});
							manage_call_register_se.variable.custom.selectedWorkflowToStage = "";
							manage_call_register_se.variable.custom.selectedWorkflowToStatus = "";
							if (allowedWorkflowArray.length != 0) {
								manage_call_register_se.variable.custom.selectedWorkflowToStage = allowedWorkflowArray[0].to_workflow_stage;
								manage_call_register_se.variable.custom.selectedWorkflowToStatus = allowedWorkflowArray[0].to_status;
								manage_call_register_se.variable.custom.selectedCallLoggedDate = mserviceUtilities.getDateObject({
										dateString : manage_call_register_se.variable.custom.selectedRecord.created_on_date,
										hourString : manage_call_register_se.variable.custom.selectedRecord.created_on_hour,
										minuteString : manage_call_register_se.variable.custom.selectedRecord.created_on_minute
									});
								manage_call_register_se.variable.custom.selectedActualStartDate = mserviceUtilities.getDateObject({
										dateString : manage_call_register_se.variable.custom.selectedRecord.act_start_on_date,
										hourString : manage_call_register_se.variable.custom.selectedRecord.act_start_on_hour,
										minuteString : manage_call_register_se.variable.custom.selectedRecord.act_start_on_minute
									});
								manage_call_register_se.variable.custom.selectedScheduledStartDate = mserviceUtilities.getDateObject({
										dateString : manage_call_register_se.variable.custom.selectedRecord.sch_start_on_date,
										hourString : manage_call_register_se.variable.custom.selectedRecord.sch_start_on_hour,
										minuteString : manage_call_register_se.variable.custom.selectedRecord.sch_start_on_minute
									});
								manage_call_register_se.variable.custom.selectedScheduledFinishDate = mserviceUtilities.getDateObject({
										dateString : manage_call_register_se.variable.custom.selectedRecord.sch_finish_on_date,
										hourString : manage_call_register_se.variable.custom.selectedRecord.sch_finish_on_hour,
										minuteString : manage_call_register_se.variable.custom.selectedRecord.sch_finish_on_minute
									});
								webNavigationController.gotoNextScreen({
									screenID : "manage_call_register_se",
									nextScreenID : "manage_call_stockin",
									nextScreenName : "Stockin Update"
								});

							} else {
								alert("Sorry. This feature is unavailable for the selected record.");
								return false;
							}
						} else {
							alert("Sorry. This feature is unavailable. Please contact support desk.");
							return false;
						}
					} else {
						alert("You do not have access to this call.");
						return false;
					}
				} else {
					alert("No row has been selected");
					return false;
				}
			}  else if (manage_call_register_se.variable.custom.selectedFeatureID == "generate_pwclaim_document") {
				if (manage_call_register_se.variable.custom.grid_1.select().length != 0) {
					var generate_pwclaim = new kendo.data.DataSource({
						pageSize : 10,
						transport : {
							read : {
								async : false,
								type : "POST",
								dataType : 'json',
								contentType : "application/json; charset=utf-8",
								url : getWebserverpath() + "api/mservice/generate_pwclaim",
								complete : function (data, textstatus) {
									if(generate_pwclaim.data()[0] != null){
										if (generate_pwclaim.data()[0].p_update_status == "SP001") {
											alert("PWC Document generated successfully. Your PWC Document reference number is " + generate_pwclaim.data()[0].p_pwclaim_ref_no);
											manage_call_register_se.variable.custom.grid_1.dataSource.pageSize(50);
											return true;
										} 
									} else {
										alert("Generation of PWC Document failed.");
										return false;
									}							
								}
							},
							parameterMap : function (data, type) {
								return mserviceUtilities.getTransportParameter({
									inputparam : {
										p_call_jo_project_ind : "'C'",
										p_call_jo_project_ref_no : "$manage_call_register_se.variable.custom.selectedRecord.call_no"
									}
								});
							}
						},
						schema : {
							parse : function (response) {
								return [response.outputparam_header];
							}
						}
					});
					generate_pwclaim.read();
				} else {
					alert("No row has been selected.");
					return false;
				}
			}  else if (manage_call_register_se.variable.custom.selectedFeatureID == "customer_feedback") {
				if (manage_call_register_se.variable.custom.grid_1.select().length != 0) {
					$.ajax({
					url : mserviceUtilities.getWebserverpath() + "feedback/feedback_web.html?call_ref_no=" + manage_call_register_se.variable.custom.selectedRecord.call_no,
					async : false,
					cache : false
					}).done(function (data) {
						$("#manage_call_register_se_child_window").append("<div id='manage_call_register_se_child_window_feedback'><div>" + data + "</div></div>");
						$("#manage_call_register_se_child_window_feedback").kendoWindow({
							width : "80%",
							height : "70%",
							title : "Customer Feedback",
							visible : false,
							modal : true,
							deactivate : function () {
								this.destroy();
							},
						});
						$("#manage_call_register_se_child_window_feedback").data("kendoWindow").center().open();
					}).fail(function (){
						alert("Sorry. This feature is unavailable. Please contact support desk.");
					});
							 
				} else {
					alert("No row has been selected");
					return false;
				}
			} else if (manage_call_register_se.variable.custom.selectedFeatureID == "add_on_engineer") {
				if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_manage_add_on_engineer.js","../../s_iscripts/custominfo_setDetail.js"])){
					webNavigationController.gotoNextScreen({
						screenID : "manage_add_on_engineer",
						fieldID : "manage_call_register_se_child_window",
						nextScreenID : "manage_add_on_engineer",
						nextScreenName : manage_call_register_se.variable.custom.nextScreenName,
						execute : manage_add_on_engineer.constructScreen
					});
				} else {
					alert("Sorry. This feature is unavailable. Please contact support desk.");
					return false;
				};
			};
		},
		workflow_btn_click : function (element, event) {
			var allowedWorkflowArray;
			if (manage_call_register_se.variable.custom.grid_1.select().length != 0) {
				if (manage_call_register_se.customRequirementHandler.validateAccess(element)) {
					if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_manage_call_register_se_wfeventverb_status_change.js", "../../s_iscripts/update_call_wfeventverb_status_change.js"])) {
						manage_call_register_se.variable.custom.selectedRecord = manage_call_register_se.variable.custom.grid_1.dataSource.getByUid(manage_call_register_se.variable.custom.grid_1.select().data("uid"));
						allowedWorkflowArray = mserviceUtilities.getNextWorkflowEventVerbs({
								transactionType : "CALL",
								eventVerb : manage_call_register_se.variable.custom.selectedWorkflowEventVerb,
								requestCategory : manage_call_register_se.variable.custom.selectedRecord.call_category,
								requestType : manage_call_register_se.variable.custom.selectedRecord.call_type,
								fromStage : manage_call_register_se.variable.custom.selectedRecord.workflow_stage_no,
								fromStatus : manage_call_register_se.variable.custom.selectedRecord.call_status
							});
						manage_call_register_se.variable.custom.selectedWorkflowToStage = "";
						manage_call_register_se.variable.custom.selectedWorkflowToStatus = "";
						if (allowedWorkflowArray.length != 0) {
							manage_call_register_se.variable.custom.selectedWorkflowToStage = allowedWorkflowArray[0].to_workflow_stage;
							manage_call_register_se.variable.custom.selectedWorkflowToStatus = allowedWorkflowArray[0].to_status;
							manage_call_register_se.variable.custom.selectedCallLoggedDate = mserviceUtilities.getDateObject({
									dateString : manage_call_register_se.variable.custom.selectedRecord.created_on_date,
									hourString : manage_call_register_se.variable.custom.selectedRecord.created_on_hour,
									minuteString : manage_call_register_se.variable.custom.selectedRecord.created_on_minute
								});
							manage_call_register_se.variable.custom.selectedActualStartDate = mserviceUtilities.getDateObject({
									dateString : manage_call_register_se.variable.custom.selectedRecord.act_start_on_date,
									hourString : manage_call_register_se.variable.custom.selectedRecord.act_start_on_hour,
									minuteString : manage_call_register_se.variable.custom.selectedRecord.act_start_on_minute
								});
							manage_call_register_se.variable.custom.selectedScheduledStartDate = mserviceUtilities.getDateObject({
									dateString : manage_call_register_se.variable.custom.selectedRecord.sch_start_on_date,
									hourString : manage_call_register_se.variable.custom.selectedRecord.sch_start_on_hour,
									minuteString : manage_call_register_se.variable.custom.selectedRecord.sch_start_on_minute
								});
							manage_call_register_se.variable.custom.selectedScheduledFinishDate = mserviceUtilities.getDateObject({
									dateString : manage_call_register_se.variable.custom.selectedRecord.sch_finish_on_date,
									hourString : manage_call_register_se.variable.custom.selectedRecord.sch_finish_on_hour,
									minuteString : manage_call_register_se.variable.custom.selectedRecord.sch_finish_on_minute
								});
							webNavigationController.gotoNextScreen({
								screenID : "manage_call_register_se",
								fieldID : "manage_call_register_se_child_window",
								nextScreenID : "manage_call_register_se_wfeventverb_status_change",
								nextScreenName : manage_call_register_se.variable.custom.nextScreenName,
								windowWidth : 800,
								execute : manage_call_register_se_wfeventverb_status_change.constructScreen
							});
						} else {
							alert("Sorry. This feature is unavailable for the selected record.");
							return false;
						}
					} else {
						alert("Sorry. This feature is unavailable. Please contact support desk.");
						return false;
					}
				} else {
					alert("You do not have access to this call.");
					return false;
				}
			} else {
				alert("No row has been selected.");
				return false;
			}
		}
	},
	linkEventHandler : {
		actions_link_click : function (element,event){
			$("#manage_call_register_se_contextMenu").data("kendoContextMenu").open(element);
			manage_call_register_se.variable.custom.contextChildElement = $('#manage_call_register_se_contextMenu').children();
			for (i = 0; i < manage_call_register_se.variable.custom.contextChildElement.length; i++){
				if (manage_call_register_se.variable.custom.contextChildElement[i].dataset.buttonGroup == 'workflow'){
					$('#' + screenID + '_'+ manage_call_register_se.variable.custom.contextChildElement[i].dataset.buttonRole + '_btn').hide();
				}
			}
			manage_call_register_se.variable.custom.selectedRecord = manage_call_register_se.variable.custom.grid_1.dataSource.getByUid(manage_call_register_se.variable.custom.grid_1.select().data("uid"));
			allowedWorkflowArray = mserviceUtilities.getAllowedWorkflowEventVerbs({
					transactionType : "CALL",
					requestCategory : manage_call_register_se.variable.custom.selectedRecord.call_category,
					requestType : manage_call_register_se.variable.custom.selectedRecord.call_type,
					fromStage : manage_call_register_se.variable.custom.selectedRecord.workflow_stage_no,
					fromStatus : manage_call_register_se.variable.custom.selectedRecord.call_status
				});
				
			for (workFlowLength = 0; workFlowLength < allowedWorkflowArray.length; workFlowLength ++){
				currentFeature  = allowedWorkflowArray[workFlowLength].child_screen_id;
				for (i = 0; i < manage_call_register_se.variable.custom.contextChildElement.length; i++){
					if (manage_call_register_se.variable.custom.contextChildElement[i].dataset.buttonRole == currentFeature ){
						$('#' + screenID + '_'+ manage_call_register_se.variable.custom.contextChildElement[i].dataset.buttonRole + '_btn').show();
						break;
					}
				} 
			}
			$("#manage_call_register_se_contextMenu").show();
			var columnData = $.grep(manage_call_register_se.variable.custom.contextChildElement, function (data) {
				if($('#' + data.id ).is(':visible')){ $('#' + data.id ).css("display","inline-block").css("min-width","180px"); }
				return $('#' + data.id ).is(':visible');
			});
			var columnCount = parseInt(columnData.length / 6);
			if((columnData.length % 6) != 0){ 
				columnCount = columnCount + 1;
			}
			$("#manage_call_register_se_contextMenu").css("columns", columnCount.toString()).css("width", "min-content");
			
			
		},
		quotation_reference_link_click : function (element, event) {
			if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_manage_quotation_master_service_spares.js"])) {
				var nextScreenProperties = $.grep(access_profile.user_functional_access, function (element, index) {
					return element.child_screen_id == "manage_quotation_master_service_spares";
				});
				manage_quotation_master_service_spares.variable.custom.linkRefInd = "true";
				webNavigationController.gotoNextScreen({
					screenID : "manage_call_register_se",
					nextScreenID : "manage_quotation_master_service_spares",
					nextScreenName : nextScreenProperties[0].child_feature_display_label
				});
				$("#manage_call_register_se").remove();
				for(var index = 0; index < webNavigationController.variable.navigationMap.length; index++){
					if(webNavigationController.variable.navigationMap[index].screenID == "manage_call_register_se"){
						webNavigationController.variable.navigationMap.splice(index,1);
					}
					if(webNavigationController.variable.navigationMap[index].screenID == "manage_quotation_master_service_spares"){
						webNavigationController.variable.navigationMap[index].parentScreenID = "home_container";
					}
				}
				screenID = "manage_quotation_master_service_spares";
				webNavigationController.buildBreadCrumb();
				$("#manage_quotation_master_service_spares_quotation_number_filter").setVal($(element).text());
				manage_quotation_master_service_spares.variable.custom.grid_1.dataSource.read();
			} else {
				alert("Sorry. This feature is unavailable. Please contact your support desk.");
				return false;
			}															 
		},
			pwclaim_reference_link_click : function (element, event) {
			if (mserviceUtilities.loadJSScripts(["../scripts/js/fn_manage_pwclaim_header.js"])) {
				var nextScreenProperties = $.grep(access_profile.user_functional_access, function (element, index) {
					return element.child_screen_id == "manage_pwclaim_header";
				});
				manage_pwclaim_header.variable.custom.linkRefInd = "true";
				webNavigationController.gotoNextScreen({
					screenID : "manage_call_register_se",
					nextScreenID : "manage_pwclaim_header",
					nextScreenName : nextScreenProperties[0].child_feature_display_label
				});
				$("#manage_call_register_se").remove();
				for(var index = 0; index < webNavigationController.variable.navigationMap.length; index++){
					if(webNavigationController.variable.navigationMap[index].screenID == "manage_call_register_se"){
						webNavigationController.variable.navigationMap.splice(index,1);
					}
					if(webNavigationController.variable.navigationMap[index].screenID == "manage_pwclaim_header"){
						webNavigationController.variable.navigationMap[index].parentScreenID = "home_container";
					}
				}
				screenID = "manage_pwclaim_header";
				webNavigationController.buildBreadCrumb();
				$("#manage_pwclaim_header_pwclaim_number_filter").setVal($(element).text());
				manage_pwclaim_header.variable.custom.grid_1.dataSource.read();
			} else {
				alert("Sorry. This feature is unavailable. Please contact your support desk.");
				return false;
			}
		}
	},
	customRequirementHandler : {
		gridPager : function () {
			$("#manage_call_register_se_grid_1").find(".k-grid-content").css("height", 498 - $("#manage_call_register_se_grid_1").find(".k-grid-header").height());
		},
		getFilterValues : function () {
			return $("#manage_call_register_se_content_1").getInputparamXML({
				screenID : "manage_call_register_se",
				matchCondition : ["_filter"]
			});
		},
		setSelectedRecord : function () {
			manage_call_register_se.variable.custom.selectedRecord = manage_call_register_se.variable.custom.grid_1.dataSource.getByUid(manage_call_register_se.variable.custom.grid_1.select().data("uid"));
		},
		validateAccess : function (buttonId) {
			if (login_profile.user_group_id == "clientadmn" || login_profile.user_group_id == "sadmn") {
				return true;
			} else {
				var featureArray = $.grep(access_profile.user_functional_access, function (element, index) {
						return (element.child_screen_id == $(buttonId).attr('data-button-role'));
					});
				var callObject = manage_call_register_se.variable.custom.selectedRecord;
				manage_call_register_se.variable.custom.datasource_2.read();
				if ((callObject.assigned_to_emp_id == undefined || callObject.assigned_to_emp_id == "") || (callObject.assigned_to_emp_id == login_profile.emp_id || callObject.assignee_mapped_to_emp_id == login_profile.emp_id)) {
					var validateAccessArray = $.grep(manage_call_register_se.variable.custom.datasource_2.data(), function (element, index) {
							return (element.trans == "CALL" && element.catg == callObject.call_category && element.type == callObject.call_type && (element.feature == featureArray[0].child_feature_id_or_group || element.feature == "ALL") && element.role_ind == "FR" && element.role_id == login_profile.functional_role_id && element.allow_rest_ind == "R");
						});
					if (validateAccessArray.length == 0) {
						validateAccessArray = $.grep(manage_call_register_se.variable.custom.datasource_2.data(), function (element, index) {
								return (element.trans == "CALL" && element.catg == callObject.call_category && element.type == "ALL" && (element.feature == featureArray[0].child_feature_id_or_group || element.feature == "ALL") && element.role_ind == "FR" && element.role_id == login_profile.functional_role_id && element.allow_rest_ind == "R");
							});
						if (validateAccessArray.length == 0) {
							validateAccessArray = $.grep(manage_call_register_se.variable.custom.datasource_2.data(), function (element, index) {
									return (element.trans == "CALL" && element.catg == "ALL" && element.type == "ALL" && (element.feature == featureArray[0].child_feature_id_or_group || element.feature == "ALL") && element.role_ind == "FR" && element.role_id == login_profile.functional_role_id && element.allow_rest_ind == "R");
								});
							if (validateAccessArray.length != 0) {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					var validateAccessArray = $.grep(manage_call_register_se.variable.custom.datasource_2.data(), function (element, index) {
							return (element.trans == "CALL" && element.catg == callObject.call_category && element.type == callObject.call_type && (element.feature == featureArray[0].child_feature_id_or_group || element.feature == "ALL") && element.role_ind == "FR" && element.role_id == login_profile.functional_role_id && element.allow_rest_ind == "A");
						});
					if (validateAccessArray.length == 0) {
						validateAccessArray = $.grep(manage_call_register_se.variable.custom.datasource_2.data(), function (element, index) {
								return (element.trans == "CALL" && element.catg == callObject.call_category && element.type == "ALL" && (element.feature == featureArray[0].child_feature_id_or_group || element.feature == "ALL") && element.role_ind == "FR" && element.role_id == login_profile.functional_role_id && element.allow_rest_ind == "A");
							});
						if (validateAccessArray.length == 0) {
							validateAccessArray = $.grep(manage_call_register_se.variable.custom.datasource_2.data(), function (element, index) {
									return (element.trans == "CALL" && element.catg == "ALL" && element.type == "ALL" && (element.feature == featureArray[0].child_feature_id_or_group || element.feature == "ALL") && element.role_ind == "FR" && element.role_id == login_profile.functional_role_id && element.allow_rest_ind == "A");
								});
							if (validateAccessArray.length == 0) {
								return false;
							}
						}
					}
				}
				return true;
			}
		},
		getExportConfig : function (gridId) {
			if(gridId == "manage_call_register_se_grid_1_export_btn"){
				return {
					type : "csv",
					template : "manage_call_register_se",
					service : "sp_retrieve_manage_call_register",
					request : "<signature><i_inputparam_xml>" + manage_call_register_se.customRequirementHandler.getFilterValues().replace("</inputparam>","<skip>0</skip><take>" + manage_call_register_se.variable.custom.grid_1.dataSource.data()[0].total + "</take></inputparam>") + "</i_inputparam_xml><o_retrieve_status></o_retrieve_status></signature>",
					length : manage_call_register_se.variable.custom.grid_1.dataSource.data().length
				};
			}
		},
		formValueAssignment : function () {
			manage_call_register_se.variable.custom.formData = mserviceUtilities.getTransportPagingDataSource({
				applicationName : "common_modules",
				serviceName : "retrieve_manage_custom_info_list",
				outputPath : "outputparam_detail",
				api : true,
				pageSize : 50,
				inputParameter : {
					p_custom_info_code : "'form_data'",
					p_inputparam_xml : `$'{"request_ref_no": "' + manage_call_register_se.variable.custom.selectedRecord.call_no + '","form_name": "' + manage_call_register_se.variable.custom.miscID + '"}'`
				},
				screenID : "manage_call_register_se"
			})
			manage_call_register_se.variable.custom.formData.read()
			if(manage_call_register_se.variable.custom.formData.data().length != 0){
				if (manage_call_register_se.variable.custom.formData.data()[0].data_type == "XML"){
					manage_call_register_se.customRequirementHandler.xmlDataToXmlDoc(manage_call_register_se.variable.custom.formData.data()[0].data, function (xmlDoc){
						form_handler.variable.custom.fieldValueAssginmentData = manage_call_register_se.customRequirementHandler.xmlDocToJSON(xmlDoc).inputparam
					}, function (){
						form_handler.variable.custom.fieldValueAssginmentData = ""
					})
				} else if (manage_call_register_se.variable.custom.formData.data()[0].data_type === "JSON"){
					form_handler.variable.custom.fieldValueAssginmentData = manage_call_register_se.variable.custom.formData.data()[0].data
				}
				form_handler.variable.custom.fieldValueAssginmentPage = Array.from($("#form_handler_" + form_handler.variable.template).children())
				for (var fieldValueAssginmentPageCount = 0; fieldValueAssginmentPageCount < form_handler.variable.custom.fieldValueAssginmentPage.length; fieldValueAssginmentPageCount++) {
					if(fieldValueAssginmentPageCount > 0){ 
						$("#form_handler_next_page_btn").click() 
					}
					for (var fieldValueAssginmentPageChildCount = 0; fieldValueAssginmentPageChildCount < $(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().length; fieldValueAssginmentPageChildCount++) {
						if ($(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().eq(fieldValueAssginmentPageChildCount).attr("id") != undefined) {
							fieldID = (($(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().eq(fieldValueAssginmentPageChildCount).attr("id")).replace("_group", "")).replace("form_handler_" + form_handler.variable.template + "_", "")
							Object.entries(form_handler.variable.custom.fieldValueAssginmentData).forEach(value => {
								if (value.at(1) != "") {
									if (value.at(0) == fieldID) {
										if ($("#" + ($(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().eq(fieldValueAssginmentPageChildCount).attr("id"))).attr("data-mloop-base") == "mAttachment" && typeof(value.at(1)) == "object") {
											$("#" + ($(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().eq(fieldValueAssginmentPageChildCount).attr("id")).replace("_group", "") + "_textarea").formHandlerSetVal(value.at(1))
										} else if ($("#" + ($(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().eq(fieldValueAssginmentPageChildCount).attr("id"))).attr("data-mloop-base") == "mLoop" && typeof(value.at(1)) == "object") {
											for (var valueCount = 0; valueCount < value.at(1).length; valueCount++) {
												if (value.at(1).length > valueCount + 1) {
													$("#" + ($(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().eq(fieldValueAssginmentPageChildCount).attr("id")).replace("_group", "") + "-" + valueCount + "_btn").click()
													$("#" + ($(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().eq(fieldValueAssginmentPageChildCount).attr("id")).replace("_group", "") + "_textarea-" + valueCount + "_btn").click()
												}
												Object.entries(value.at(1).at(valueCount)).forEach(data => {
													if ($("#form_handler_" + form_handler.variable.template + "_" + data.at(0) + "-" + valueCount + "_group").attr("data-mloop-base") == "mAttachment" && typeof(data.at(1)) == "object") {
														$("#form_handler_" + form_handler.variable.template + "_" + data.at(0) + "_textarea-" + valueCount).formHandlerSetVal(data.at(1))
													} else {
														$("#form_handler_" + form_handler.variable.template + "_" + data.at(0) + "-" + valueCount).formHandlerSetVal(data.at(1))
													}
												})
											}
										} else {
											if ($("#" + ($(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().eq(fieldValueAssginmentPageChildCount).attr("id"))).attr("data-mloop-base") == "mDatebox"){
												$("#" + ($(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().eq(fieldValueAssginmentPageChildCount).attr("id")).replace("_group", "")).formHandlerSetVal(new Date(value.at(1)))
											} else {
												$("#" + ($(form_handler.variable.custom.fieldValueAssginmentPage).eq(fieldValueAssginmentPageCount).children().eq(fieldValueAssginmentPageChildCount).attr("id")).replace("_group", "")).formHandlerSetVal(value.at(1))
											}
										}
									}
								}
							})
						}
					}
				}
				$("#form_handler_first_page_btn").click()
			}
		},
		xmlDataToXmlDoc : function (data, success, failure) {
			var decodedData,
				parser,
				xmlDoc,
				hasError
			decodedData = data.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&")
			parser = new DOMParser()
			xmlDoc = parser.parseFromString(decodedData, "text/xml")
			hasError = xmlDoc.getElementsByTagName("parsererror").length > 0
			if (hasError) {
				failure()
			} else {
				success(xmlDoc)
			}
		}, 
		xmlDocToJSON : function (data) {
			if (data.nodeType === 3) {
				return data.nodeValue.trim()
			}
			let obj = {}
			let hasElementChild = false
			for (let child of data.childNodes) {
				if (child.nodeType === 1) {
					hasElementChild = true
					const nodeName = child.nodeName
					const value = manage_call_register_se.customRequirementHandler.xmlDocToJSON(child)
					if (!obj[nodeName]) {
						obj[nodeName] = value
					} else {
						if (!Array.isArray(obj[nodeName])) {
							obj[nodeName] = [obj[nodeName]]
						}
						obj[nodeName].push(value)
					}
				}
			}
			if (!hasElementChild && data.childNodes.length === 1 && data.firstChild.nodeType === 3) {
				return data.firstChild.nodeValue.trim()
			}
			return obj
		}
	},
	variable : {
		standard : {
			reorderParam : [{
					contentID : "content_1",
					columnLength : 1
				}
			],
			importConfiguration : {
				informationType : 'call_register'
			},
			exportConfiguration : {
				mode : "single",
				content : [{
						exportType : "grid",
						fieldId : "manage_call_register_se_grid_1",
						dispalyLabel : "Data Export"
					}
				]
			},
			printConfiguration : {
				mode : "single",
				content : [{
						type : "grid",
						fieldId : "manage_call_register_se_grid_1",
						dispalyLabel : "Data Export"
					}
				]
			}
		},
		custom : {
			customerUserCustomerID : ""
		}
	}
};