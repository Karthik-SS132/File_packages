if exists (select 1 from sys.procedures where name = 'sp_update_ancillary_request_wfeventverb_status_change')
begin
/****** Object:  StoredProcedure [dbo].[sp_update_ancillary_request_wfeventverb_status_change]    Script Date: 6/7/2022 2:46:50 PM ******/
DROP PROCEDURE [dbo].[sp_update_ancillary_request_wfeventverb_status_change]
end

/****** Object:  StoredProcedure [dbo].[sp_update_ancillary_request_wfeventverb_status_change]    Script Date: 20/04/2023 15:45:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[sp_update_ancillary_request_wfeventverb_status_change]
    @i_client_id [uddt_client_id], 
    @i_country_code [uddt_country_code], 
    @i_session_id [sessionid], 
    @i_user_id [userid], 
    @i_locale_id [uddt_locale_id], 
    @i_request_ref_no [uddt_nvarchar_20], 
    @i_channel_id [uddt_varchar_20], 
    @i_wfeventverb_id [uddt_varchar_60], 
    @i_event_date [uddt_date], 
    @i_event_hour [uddt_hour], 
    @i_event_minute [uddt_minute], 
    @i_from_wf_stage_no [uddt_tinyint], 
    @i_to_wf_stage_no [uddt_tinyint], 
    @i_from_wf_status [uddt_varchar_2], 
    @i_to_wf_status [uddt_varchar_2], 
    @i_by_employee_id [uddt_employee_id],
    @i_to_employee_id_string [uddt_nvarchar_255], 
    @i_reason_code [uddt_nvarchar_50], 
    @i_comments [uddt_nvarchar_1000], 
    @i_lattitude_value [uddt_varchar_10], 
    @i_longitude_value [uddt_varchar_10], 
    @i_inputparam_xml1 [uddt_nvarchar_max], 
    @i_inputparam_xml2 [uddt_nvarchar_max], 
    @i_inputparam_xml3 [uddt_nvarchar_max], 
    @i_attachment_xml [uddt_nvarchar_max], 
    @i_rec_tstamp [uddt_uid_timestamp], 
    @i_save_mode [uddt_varchar_1], 
    @o_update_status [uddt_varchar_5] OUTPUT,
    @errorNo [errorno] OUTPUT
AS
BEGIN
    /*
     * Function to save call status change for predefined workflow events.
     */
    -- SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
    SET NOCOUNT ON;

   
    -- The following SQL snippet illustrates (with sample values) assignment of scalar output parameters
    -- returned out of this stored procedure

    -- Use SET | SELECT for assigning values
    /*
    SET 
         @o_update_status = '' /* string */
         @errorNo = ''	/* string */
     */

    /*
     * List of errors associated to this stored procedure. Use the text of the error
     * messages printed below as a guidance to set appropriate error number to @errorNo inside the procedure.
     * E_UP_005 - Update Failure : Record updated by another user. Please Retry the retrieval of the record and update.
     * E_UP_089 - Failed to make status change
     * 
     * Use the following SQL statement to set @errorNo:
     * SET @errorNo = 'One of the error numbers associated to this procedure as per list above'
     */
        declare @p_assigned_to_user_id nvarchar(12),
			@p_notification_id int, @p_from_request_status varchar(2),
			@p_by_employee_id nvarchar(12),
			@p_from_wf_stage_no tinyint, @p_to_wf_stage_no tinyint,
			@p_notification_xml nvarchar(max),
			@p_assign_to_emp_id nvarchar(12),
			@p_execution_error_message nvarchar(200)

		
		 declare @p_SQLString nvarchar(max) , @p_ParmDefinition nvarchar(max),
			@p_retrieve_status varchar(10), @p_childproc_execution_status varchar(10),
			@p_session_id [sessionid], 
			@p_user_id [userid], 
			@p_client_id [uddt_client_id], 
			@p_locale_id [uddt_locale_id], 
			@p_country_code [uddt_country_code],
			@p_request_ref_no [uddt_nvarchar_20], 
			@p_wfeventverb_id [uddt_varchar_60], 
			@p_event_date [uddt_date], 
			@p_event_hour [uddt_hour], 
			@p_event_minute [uddt_minute], 
			@p_from_wf_status [uddt_varchar_2], 
			@p_to_wf_status [uddt_varchar_2], 
			@p_rec_tstamp [uddt_uid_timestamp], 
			@p_execution_status [uddt_varchar_10],
			@p_inputparam_xml xml
		    
		declare @p_request_category varchar(10),
			@p_request_type nvarchar(10),
			@p_request_priority varchar(3),
			@p_organogram_level_no tinyint,
			@p_organogram_level_code nvarchar(15),
			@p_company_location_code nvarchar(8),
			@p_notification_event_code nvarchar(60),
			@p_notification_event_code_1 nvarchar(60),
			@p_notification_event_code_2 nvarchar(60),
			@p_notification_event_code_3 nvarchar(60),
			@p_notification_event_code_4 nvarchar(60),
			@p_notification_event_code_5 nvarchar(60)
			
	set @p_inputparam_xml = CAST( LTRIM(rtrim(@i_inputparam_xml1))+
									(case ltrim(rtrim(@i_inputparam_xml2))
									 when '' then '' else ltrim(rtrim(@i_inputparam_xml2)) end)
									+(case ltrim(rtrim(@i_inputparam_xml3))
									 when '' then '' else ltrim(rtrim(@i_inputparam_xml3)) end)
							  as XML)
	
		declare @p_online_offline_ind varchar(1)
	 
 create table #input_params
 (paramname varchar(50) not null,
  paramval nvarchar(max) null
  )
  
  create table #eventchange_notifications
  (
	notification_event_code nvarchar(60) not null
  )
  
  insert #input_params
  (paramname, paramval)
  SELECT nodes.value('local-name(.)', 'varchar(50)'),
         nodes.value('(.)[1]', 'nvarchar(max)')
  FROM @p_inputparam_xml.nodes('/inputparam/*') AS Tbl(nodes)
  
  select @p_online_offline_ind = paramval 
	from #input_params
	where paramname = 'online_offline_ind'
		
	select @p_by_employee_id = employee_id
	from users
	where company_id = @i_client_id
	  and country_code = @i_country_code
	  and user_id = @i_user_id	
	
	select @p_request_category = request_category,
			@p_request_type = request_type,
			@p_organogram_level_no = organogram_level_no,
			@p_organogram_level_code = organogram_level_code,
			@p_company_location_code = company_location_code		
	from ancillary_request_register
	where company_id = @i_client_id
	  and country_code = @i_country_code
	  and request_ref_no = @i_request_ref_no
    
		if exists ( select 1 from sys.objects
				where type = 'P' 
				  and name = OBJECT_NAME(@@PROCID)+'_'+@p_request_category+'_'+@i_client_id)
			begin
				  	
				/* Build the SQL string one time.*/
				SET @p_SQLString = 'execute '+OBJECT_NAME(@@PROCID)+'_'+@p_request_category+'_'+@i_client_id+' '+
									N'@p_client_id , 
									@p_country_code , 
									@p_session_id , 
									@p_user_id , 
									@p_locale_id , 
									@p_request_ref_no , 
									@p_channel_id,
									@p_wfeventverb_id , 
									@p_event_date , 
									@p_event_hour , 
									@p_event_minute , 
									@p_from_wf_stage_no , 
									@p_to_wf_stage_no , 
									@p_from_wf_status , 
									@p_to_wf_status , 
									@p_by_employee_id,
									@p_to_employee_id_string,
									@p_reason_code,
									@p_comments,
									@p_lattitude_value,
									@p_longitude_value,
									@p_inputparam_xml1 ,
									@p_inputparam_xml2,
									@p_inputparam_xml3,
									@p_attachment_xml, 
									@p_rec_tstamp , 
									@p_save_mode,
									@p_childproc_execution_status OUTPUT,
									@p_childproc_execution_error_message OUTPUT';
		    
				SET @p_ParmDefinition = N'@p_client_id [uddt_client_id], 
											@p_country_code [uddt_country_code], 
											@p_session_id [sessionid], 
											@p_user_id [userid], 
											@p_locale_id [uddt_locale_id], 
											@p_request_ref_no [uddt_nvarchar_20], 
											@p_channel_id [uddt_varchar_20],
											@p_wfeventverb_id [uddt_varchar_60], 
											@p_event_date [uddt_date], 
											@p_event_hour [uddt_hour], 
											@p_event_minute [uddt_minute], 
											@p_from_wf_stage_no [uddt_tinyint], 
											@p_to_wf_stage_no [uddt_tinyint], 
											@p_from_wf_status [uddt_varchar_2], 
											@p_to_wf_status [uddt_varchar_2], 
											@p_by_employee_id [uddt_employee_id],
											@p_to_employee_id_string [uddt_nvarchar_255],
											@p_reason_code [uddt_nvarchar_50],
											@p_comments [uddt_nvarchar_1000],
											@p_lattitude_value [uddt_varchar_10],
											@p_longitude_value [uddt_varchar_10],
											@p_inputparam_xml1 [uddt_nvarchar_max], 
											@p_inputparam_xml2 [uddt_nvarchar_max], 
											@p_inputparam_xml3 [uddt_nvarchar_max],
											@p_attachment_xml [uddt_nvarchar_max], 
											@p_rec_tstamp [uddt_uid_timestamp], 
											@p_save_mode [uddt_varchar_1],
											@p_childproc_execution_status [uddt_varchar_10] OUTPUT,
											@p_childproc_execution_error_message [uddt_nvarchar_200] OUTPUT';
				    
				/* Execute the string with the first parameter value. */
				
				EXECUTE sp_executesql @p_SQLString, @p_ParmDefinition,
									   @p_client_id = @i_client_id , 
										@p_country_code = @i_country_code , 
										@p_session_id = @i_session_id, 
										@p_user_id = @i_user_id, 
										@p_locale_id = @i_locale_id, 
										@p_request_ref_no = @i_request_ref_no, 
										@p_channel_id = @i_channel_id,
										@p_wfeventverb_id = @i_wfeventverb_id, 
										@p_event_date = @i_event_date, 
										@p_event_hour = @i_event_hour, 
										@p_event_minute = @i_event_minute, 
										@p_from_wf_stage_no = @i_from_wf_stage_no, 
										@p_to_wf_stage_no = @i_to_wf_stage_no, 
										@p_from_wf_status = @i_from_wf_status, 
										@p_to_wf_status = @i_to_wf_status, 
										@p_by_employee_id = @i_by_employee_id,
										@p_to_employee_id_string = @i_to_employee_id_string,
										@p_reason_code = @i_reason_code,
										@p_comments = @i_comments,
										@p_lattitude_value = @i_lattitude_value,
										@p_longitude_value = @i_longitude_value,
										@p_inputparam_xml1 = @i_inputparam_xml1,
										@p_inputparam_xml2 = @i_inputparam_xml2,
										@p_inputparam_xml3 = @i_inputparam_xml3,
										@p_attachment_xml = @i_attachment_xml, 
										@p_rec_tstamp = @i_rec_tstamp, 
										@p_save_mode = @i_save_mode,
										@p_childproc_execution_status = @p_execution_status OUTPUT,
										@p_childproc_execution_error_message = @p_execution_error_message OUTPUT;
										
			if @p_execution_status != 'SUCCESS'
				begin
					if @i_channel_id in ( 'SMS', 'MOBILE') and @p_online_offline_ind = 'F'
					begin
					
						insert audit_transaction_log
						(
							client_id , 
							country_code , 
							session_id , 
							user_id , 
							locale_id , 
							channel_id ,
							created_on_date ,
							call_ref_no , 
							wfeventverb_id , 
							event_date , 
							event_hour ,
							event_minute , 
							from_wf_stage_no , 
							to_wf_stage_no , 
							from_wf_status , 
							to_wf_status , 
							by_employee_id ,
							to_employee_id_string , 
							reason_code , 
							comments , 
							lattitude_value , 
							longitude_value , 
							inputparam_xml1 , 
							inputparam_xml2 , 
							inputparam_xml3 , 
							attachment_xml , 
							rec_tstamp, 
							save_mode  
						)
						select 	@i_client_id , 
							@i_country_code , 
							@i_session_id , 
							@i_user_id , 
							@i_locale_id , 
							@i_channel_id ,
							SYSDATETIMEOFFSET(),
							@i_request_ref_no , 
							@i_wfeventverb_id , 
							@i_event_date , 
							@i_event_hour ,
							@i_event_minute , 
							@i_from_wf_stage_no , 
							@i_to_wf_stage_no , 
							@i_from_wf_status , 
							@i_to_wf_status , 
							@i_by_employee_id ,
							@i_to_employee_id_string , 
							@i_reason_code , 
							@i_comments , 
							@i_lattitude_value , 
							@i_longitude_value , 
							@i_inputparam_xml1 , 
							@i_inputparam_xml2 , 
							@i_inputparam_xml3 , 
							@i_attachment_xml , 
							@i_rec_tstamp, 
							@i_save_mode 
					end
					RAISERROR(@p_execution_error_message,15,1)
					set @errorNo = 'E_UP_089'
					return				
				end
		end   
	/* Determine if there are any events configured in notification rules */	
	select @p_request_category = request_category,
			@p_request_type = request_type,
			@p_organogram_level_no = organogram_level_no,
			@p_organogram_level_code = organogram_level_code,
			@p_company_location_code = company_location_code		
	from ancillary_request_register
	where company_id = @i_client_id
	  and country_code = @i_country_code
	  and request_ref_no = @i_request_ref_no
	  
	  /* 22.Jan.17 - Below code to be fixed. Code is temporary due to workflow scheduler not available */
	  
	  if @i_client_id in ('acopco','dynapac','epiroc','cp') and @i_wfeventverb_id = 'SAVEFORASSIGN'
	  begin
	  
		if (select request_status from ancillary_request_register
			where company_id = @i_client_id
			  and country_code = @i_country_code
			  and request_ref_no = @i_request_ref_no) = 'A'
		begin	  
			select @i_from_wf_stage_no = 1, @i_from_wf_status = 'O',
					@i_to_wf_stage_no = 2, @i_to_wf_status = 'A'
		end
		
	  end
	  
	  /****/
	  
	  execute sp_get_notification_event_code_for_ancillary 
				@i_client_id,
				@i_country_code, 
				@i_session_id, 
				@i_user_id, 
				@i_locale_id , 
				@p_organogram_level_no,
				@p_organogram_level_code ,
				@p_company_location_code ,		
				@p_request_category , 
				@p_request_type ,
				@p_request_priority ,
				'W' ,
				'FT' ,
				@i_from_wf_stage_no , 
				@i_to_wf_stage_no , 
				@i_from_wf_status , 
				@i_to_wf_status , 
				@p_notification_event_code_1 OUTPUT,
				@p_notification_event_code_2 OUTPUT,
				@p_notification_event_code_3 OUTPUT,
				@p_notification_event_code_4 OUTPUT,
				@p_notification_event_code_5 OUTPUT

	
	if isnull(@p_notification_event_code_1,'') != ''
	begin
	
		insert #eventchange_notifications
		(
			notification_event_code
		)
		select @p_notification_event_code_1
		
	end
	if isnull(@p_notification_event_code_2,'') != ''
	begin
	
		insert #eventchange_notifications
		(
			notification_event_code
		)
		select @p_notification_event_code_2
		
	end
	if isnull(@p_notification_event_code_3,'') != ''
	begin
	
		insert #eventchange_notifications
		(
			notification_event_code
		)
		select @p_notification_event_code_3
		
	end
	if isnull(@p_notification_event_code_4,'') != ''
	begin
	
		insert #eventchange_notifications
		(
			notification_event_code
		)
		select @p_notification_event_code_4
		
	end
	if isnull(@p_notification_event_code_5,'') != ''
	begin
	
		insert #eventchange_notifications
		(
			notification_event_code
		)
		select @p_notification_event_code_5
		
	end
	
	declare retrieve_applicable_notification_events_cursor cursor for
	select notification_event_code
	from #eventchange_notifications
	
	open retrieve_applicable_notification_events_cursor
	
	fetch retrieve_applicable_notification_events_cursor
	into
	@p_notification_event_code
	
	while @@FETCH_STATUS = 0
	begin
	
	if exists ( select 1 from company_notification a
				where a.company_id = @i_client_id
				  and a.country_code = @i_country_code
				  and a.notification_event_code = @p_notification_event_code
				  and active_ind = 1)
	begin
		
		
			/* Below query only picks one assignee. Need to fix for multiple assignees - Chak 22.Apr.15*/
			
			select top(1) @p_assign_to_emp_id = b1.resource_emp_id
			from ancillary_request_workflow_assignment b1
			where b1.company_id = @i_client_id
			  and b1.country_code = @i_country_code
			  and b1.request_ref_no = @i_request_ref_no
			  and b1.current_assignee_ind = 1
			  and b1. assigned_on_date = 
					( select MAX(b2.assigned_on_date )
						from ancillary_request_workflow_assignment b2
						where b1.company_id = b2.company_id
						and b2.request_ref_no = b1.request_ref_no)	
		
		if @i_wfeventverb_id = 'ASSIGN'
		begin
			
		 select @p_notification_xml = '<notification_info>'+
							'<request_no>'+@i_request_ref_no+'</request_no>'+
							'<request_type>'+
							  case (select 1 from code_table_mlingual_translation f
								where f.company_id = @i_client_id
								  and f.country_code = @i_country_code
								  and f.locale_id = @i_locale_id
								  and f.code_type = 'ANCILLARYTYPE'
								  and f.code = a.request_type)
							when 1 then
							(select e.short_description 
								from code_table_mlingual_translation e
							where e.company_id = @i_client_id
							  and e.country_code = @i_country_code
							  and e.locale_id = @i_locale_id
							  and e.code_type = 'ANCILLARYTYPE'
							  and e.code = a.request_type)
							else
							(select g.short_description from code_table_mlingual_translation g
							where g.company_id = @i_client_id
							  and g.country_code = @i_country_code
							  and g.locale_id = 'ALL'
							  and g.code_type = 'ANCILLARYTYPE'
							  and g.code = a.request_type)
							end 
							+'</request_type>'+
							'<cust_id>'+isnull(c.customer_id,'')+'</cust_id>'+
							'<cust_name>'+isnull(substring(c.customer_name,1,20),'') +'</cust_name>'+
							'<cust_contact_name>'+isnull(substring(a.customer_contact_name,1,20),'') +'</cust_contact_name>'+
							'<cust_contact_no>'+isnull(a.customer_contact_no,'') +'</cust_contact_no>'+
							'<cust_contact_email_id>'+ISNULL(a.customer_contact_email_id,'')+'</cust_contact_email_id>'+
							'<request_logged_on_date>'+CONVERT(varchar(30),SYSDATETIMEOFFSET(),0)+'</request_logged_on_date>'+
							--'<asset_location_code>'+isnull(a.asset_location_code_reported,'')+'</asset_location_code>'+
							--'<description>'+isnull(a.problem_description,'')+'</description>'+
							'<assigned_to_emp_id>'+
									isnull(@p_assign_to_emp_id	,'')  					
							+'</assigned_to_emp_id>'+
							'<created_by_employee_name>'+ISNULL(( select c1.first_name+' '+c1.last_name
								from employee c1
								where c1.company_id = @i_client_id
								and c1.country_code = @i_country_code
								and c1.employee_id = a.created_by_employee_id),'')+
								'</created_by_employee_name>'+
								'<comments>'+isnull((select top(1) csed.comments
									from ancillary_request_status_event_log csed
										where csed.request_ref_no = @i_request_ref_no 
										and csed.eventverb_id = @i_wfeventverb_id
										order by csed.event_id desc),'')+
								'</comments>'+
							'<assigned_to_emp_name>'+
							isnull((
								select title+' '+first_name+' '+last_name
								from employee b
								where b.company_id = @i_client_id
								  and b.country_code = @i_country_code
								  and b.employee_id = @p_assign_to_emp_id
							),'')
							+'</assigned_to_emp_name>'+
							'<assigned_to_emp_contact_no>'+
							isnull((
								select b2.contact_mobile_no
								from employee b2
								where b2.company_id = @i_client_id
								  and b2.country_code = @i_country_code
								  and b2.employee_id = @p_assign_to_emp_id	
							),'')
							+'</assigned_to_emp_contact_no>'+
							'<sch_start_date>'+isnull(convert(varchar(11),a.sch_start_date,109),'')+' '+
							+substring(convert(varchar(30),a.sch_start_date,100),13,7)
							+'</sch_start_date>'+
							'<udf_char_1>'+isnull(a.udf_char_1,'')+'</udf_char_1>'+												 
							'<udf_bit_4>'+cast(isnull(a.udf_bit_4,0) as varchar(1))+'</udf_bit_4>'+
							'<udf_date_1>'+isnull(CONVERT(varchar(20),a.udf_date_1,100),'')+'</udf_date_1>'+												 
							'<support_desk_no>Service Coordinator</support_desk_no>'+
							'</notification_info>'	
		  from ancillary_request_register a
		  left outer join customer c
		  on a.company_id = c.company_id
			and a.country_code = c.country_code
			and a.customer_id = c.customer_id
		  where a.company_id = @i_client_id
			and a.country_code = @i_country_code
			and a.request_ref_no = @i_request_ref_no
	
		end
		else
		begin
		 select @p_notification_xml = '<notification_info>'+
							'<request_no>'+@i_request_ref_no+'</request_no>'+
							'<request_type>'+
							  case (select 1 from code_table_mlingual_translation f
								where f.company_id = @i_client_id
								  and f.country_code = @i_country_code
								  and f.locale_id = @i_locale_id
								  and f.code_type = 'ANCILLARYTYPE'
								  and f.code = a.request_type)
							when 1 then
							(select e.short_description 
								from code_table_mlingual_translation e
							where e.company_id = @i_client_id
							  and e.country_code = @i_country_code
							  and e.locale_id = @i_locale_id
							  and e.code_type = 'ANCILLARYTYPE'
							  and e.code = a.request_type)
							else
							(select g.short_description from code_table_mlingual_translation g
							where g.company_id = @i_client_id
							  and g.country_code = @i_country_code
							  and g.locale_id = 'ALL'
							  and g.code_type = 'ANCILLARYTYPE'
							  and g.code = a.request_type)
							end 
							+'</request_type>'+
							'<request_status>'+a.request_status+'</request_status>'+
						   '<request_status_desc>'+
	   						case (select 1 from code_table_mlingual_translation f
									where f.company_id = @i_client_id
									  and f.country_code = @i_country_code
									  and f.locale_id = @i_locale_id
									  and f.code_type = 'ANCILLARYSTATUS'
									  and f.code = a.request_ref_no)
								when 1 then
								(select e.long_description 
									from code_table_mlingual_translation e
								where e.company_id = @i_client_id
								  and e.country_code = @i_country_code
								  and e.locale_id = @i_locale_id
								  and e.code_type = 'ANCILLARYSTATUS'
								  and e.code = a.request_ref_no)
								else
								(select g.long_description from code_table_mlingual_translation g
								where g.company_id = @i_client_id
								  and g.country_code = @i_country_code
								  and g.locale_id = 'ALL'
								  and g.code_type = 'ANCILLARYSTATUS'
								  and g.code = a.request_status)
							 end +
							'</request_status_desc>'+
						   '<workflow_stage_no>' + convert(varchar(3), a. request_wf_stage_no) + '</workflow_stage_no>' +
							'<workflow_stage_no_desc>' + 
								isnull((
									select x.description 
									from workflow_stage_master x
									where x.company_id = @i_client_id
										and x.country_code = @i_country_code
										and x.transaction_type_code = 'ANCILLARY'
										and x.request_category = a.request_category
										and x.workflow_stage_no = a. request_wf_stage_no ), '') + 
							'</workflow_stage_no_desc>' +
							'<cust_id>'+isnull(c.customer_id,'')+'</cust_id>'+
							'<cust_name>'+isnull(substring(c.customer_name,1,20),'') +'</cust_name>'+
							'<cust_contact_name>'+isnull(substring(a.customer_contact_name,1,20),'') +'</cust_contact_name>'+
							'<cust_contact_no>'+isnull(a.customer_contact_no,'') +'</cust_contact_no>'+
							'<cust_contact_email_id>'+ISNULL(a.customer_contact_email_id,'')+'</cust_contact_email_id>'+
							'<request_logged_on_date>'+CONVERT(varchar(20),a.created_on_date,100)+'</request_logged_on_date>'+
							'<request_act_finish_date>'+isnull(convert(varchar(20),act_finish_date,100),'')
									+'</request_act_finish_date>'+
							'<reason_code>'+isnull(
							  (case @i_wfeventverb_id 
							  when 'STATUSCHANGE' then
								 (case (select 1 from code_table_mlingual_translation f
												where f.company_id = @i_client_id
													and f.country_code = @i_country_code
													and f.locale_id = @i_locale_id
													and f.code_type = 'SCHNGREASCD_'+cast(@i_to_wf_stage_no as varchar(2))+@i_to_wf_status
													and f.code = @i_reason_code)
												when 1 then
													(select e.short_description from code_table_mlingual_translation e
													where e.company_id = @i_client_id
														and e.country_code = @i_country_code
														and e.locale_id = @i_locale_id
														and e.code_type = 'SCHNGREASCD_'+cast(@i_to_wf_stage_no as varchar(2))+@i_to_wf_status
														and e.code =  @i_reason_code)
												else
												(select g.short_description from code_table_mlingual_translation g
												where g.company_id = @i_client_id
													and g.country_code = @i_country_code
													and g.locale_id = 'ALL'
													and g.code_type = 'SCHNGREASCD_'+cast(@i_to_wf_stage_no as varchar(2))+@i_to_wf_status
													and g.code =  @i_reason_code)
										end)
							 else
							   (case (select 1 from code_table_mlingual_translation f
												where f.company_id = @i_client_id
													and f.country_code = @i_country_code
													and f.locale_id = @i_locale_id
													and f.code_type = @p_wfeventverb_id+'REASCD'
													and f.code =  @i_reason_code)
											when 1 then
												(select e.short_description from code_table_mlingual_translation e
												where e.company_id = @i_client_id
													and e.country_code = @i_country_code
													and e.locale_id = @i_locale_id
													and e.code_type = @p_wfeventverb_id+'REASCD'
													and e.code =  @i_reason_code)
											else
											(select g.short_description from code_table_mlingual_translation g
											where g.company_id = @i_client_id
												and g.country_code = @i_country_code
												and g.locale_id = 'ALL'
												and g.code_type = @p_wfeventverb_id+'REASCD'
												and g.code =  @i_reason_code)
											end)
							  end) , '')
							+'</reason_code>'+
							'<comments>'+isnull(@i_comments,'')+'</comments>'+
							--'<description>'+isnull(a.problem_description,'')+'</description>'+
							'<assigned_to_emp_id>'+
									isnull(@p_assign_to_emp_id,'')	  					
							+'</assigned_to_emp_id>'+
							'<assigned_to_emp_name>'+
							isnull((
								select title+' '+first_name+' '+last_name
								from employee b
								where b.company_id = @i_client_id
								  and b.country_code = @i_country_code
								  and b.employee_id = @p_assign_to_emp_id
							),'')
							+'</assigned_to_emp_name>'+
							'<created_by_employee_name>'+ISNULL(( select c1.title+' '+c1.first_name+' '+c1.last_name
								from employee c1
								where c1.company_id = @i_client_id
								and c1.country_code = @i_country_code
								and c1.employee_id = a.created_by_employee_id),'')+
								'</created_by_employee_name>'+
								'<comments>'+isnull((select top(1) csed.comments
									from ancillary_request_status_event_log csed
										where csed.request_ref_no = @i_request_ref_no 
										and csed.eventverb_id = @i_wfeventverb_id
										order by csed.event_id desc),'')+
								'</comments>'+
								'<last_update_user>'+ISNULL(( select c1.title+' '+c1.first_name+' '+c1.last_name
								from employee c1
								where c1.company_id = @i_client_id
								and c1.country_code = @i_country_code
								and c1.employee_id = a.last_update_id),'')+
								'</last_update_user>'+
							'<assigned_to_emp_contact_no>'+
							isnull((
								select b2.contact_mobile_no
								from employee b2
								where b2.company_id = @i_client_id
								  and b2.country_code = @i_country_code
								  and b2.employee_id = @p_assign_to_emp_id	
							),'')
							+'</assigned_to_emp_contact_no>'+
							'<request_closed_by_name>'+
										(select isnull((select c1.title+'.'+c1.first_name+' '+isnull(c1.middle_name,'')+' '+c1.last_name
										from ancillary_request_register a1, ancillary_request_assignment b1, employee c1
										where a1.company_id = @i_client_id
										  and a1.country_code = @i_country_code
										  and a1.request_ref_no = @i_request_ref_no
										  and a1.company_id = b1.company_id
										  and a1.country_code = b1.country_code
										  and b1.request_ref_no = @i_request_ref_no
										  and b1.primary_resource_ind = 1
										  and b1.company_id = c1.company_id
										  and b1.country_code = c1.country_code
										  and b1.resource_emp_id = c1.employee_id),''))	  					
									+'</request_closed_by_name>'+
									'<request_closed_by_emp_contact_no>'+
										(select isnull((select c2.contact_mobile_no
										from ancillary_request_register a2, ancillary_request_assignment b2, employee c2
										where a2.company_id = @i_client_id
										  and a2.country_code = @i_country_code
										  and a2.request_ref_no = @i_request_ref_no
										  and a2.company_id = b2.company_id
										  and a2.country_code = b2.country_code
										  and a2.request_ref_no = b2.request_ref_no
										  and b2.primary_resource_ind = 1
										  and b2.company_id = c2.company_id
										  and b2.country_code = c2.country_code
										  and b2.resource_emp_id = c2.employee_id),''))	  					
									+'</request_closed_by_emp_contact_no>'+									
									'<request_closed_by_emp_contact_email>'+
										(select isnull((select c2.email_id
										from ancillary_request_register a2, ancillary_request_assignment b2, employee c2
										where a2.company_id = @i_client_id
										  and a2.country_code = @i_country_code
										  and a2.request_ref_no = @i_request_ref_no
										  and a2.company_id = b2.company_id
										  and a2.country_code = b2.country_code
										  and a2.request_ref_no = b2.request_ref_no
										  and b2.primary_resource_ind = 1
										  and b2.company_id = c2.company_id
										  and b2.country_code = c2.country_code
										  and b2.resource_emp_id = c2.employee_id),''))	  					
									+'</request_closed_by_emp_contact_email>'+									
							--'<asset_location_code>'+isnull(a.asset_location_code_reported,'')+'</asset_location_code>'+
							'<additional_information>'+isnull(a.additional_information,'')+'</additional_information>'+												 
							'<udf_char_1>'+isnull(a.udf_char_1,'')+'</udf_char_1>'+												 
							'<udf_bit_4>'+cast(isnull(a.udf_bit_4,0) as varchar(1))+'</udf_bit_4>'+
							'<udf_date_1>'+isnull(CONVERT(varchar(20),a.udf_date_1,100),'')+'</udf_date_1>'+												 
							'<support_desk_no>Service Coordinator</support_desk_no>'+
							'</notification_info>'			
		  from ancillary_request_register a
		  left outer join customer c
		  on a.company_id = c.company_id
			and a.country_code = c.country_code
			and a.customer_id = c.customer_id
		  where a.company_id = @i_client_id
			and a.country_code = @i_country_code
			and a.request_ref_no = @i_request_ref_no
		end
		
		execute sp_log_new_notification  @i_session_id, @i_user_id  , @i_client_id , 
		  @i_locale_id , @i_country_code , @p_notification_event_code ,@p_notification_xml, @i_user_id, @p_notification_id OUTPUT
		
		if @p_notification_id = 0
		begin	
			close retrieve_applicable_notification_events_cursor
			deallocate retrieve_applicable_notification_events_cursor
			set @errorNo = 'E_UP_089'
			return
		end

	end
	
	fetch retrieve_applicable_notification_events_cursor
	into
	@p_notification_event_code
	
	end
	
	close retrieve_applicable_notification_events_cursor
	deallocate retrieve_applicable_notification_events_cursor
	
	set @o_update_status = 'SP001'

    SET NOCOUNT OFF;
END