if exists (select 1 from sys.procedures where name = 'sp_retrieve_manage_custom_info_list_tada_claim')
begin
/****** Object:  StoredProcedure [dbo].[sp_retrieve_manage_custom_info_list_tada_claim]    Script Date: 6/7/2022 2:46:50 PM ******/
DROP PROCEDURE [dbo].[sp_retrieve_manage_custom_info_list_tada_claim]
end


/****** Object:  StoredProcedure [dbo].[sp_retrieve_manage_custom_info_list_tada_claim]    Script Date: 25/04/2023 12:23:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
 * Function to retrieve list of ciustom info records
 */
CREATE PROCEDURE [dbo].[sp_retrieve_manage_custom_info_list_tada_claim] 
    @i_client_id [uddt_client_id], 
    @i_country_code [uddt_country_code], 
    @i_session_id [sessionid], 
    @i_user_id [userid], 
    @i_locale_id [uddt_locale_id], 
    @i_custom_info_code [uddt_varchar_60], 
    @i_inputparam_xml [uddt_nvarchar_max], 
    @o_retrieve_status [uddt_varchar_5] OUTPUT
AS
BEGIN
    /*
     * Function to retrieve list of ciustom info records
     */
    -- SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
    SET NOCOUNT ON;

    -- The following SQL snippet illustrates (with sample values) assignment of scalar output parameters
    -- returned out of this stored procedure

    -- Use SET | SELECT for assigning values
    /*
    SET 
         @o_retrieve_status = '' /* string */
     */

    /*
    -- The following SQL snippet illustrates selection of result sets expected from this stored procedure: 
    
    -- Result set 1: custom_info_list

    SELECT
        '' as custom_info_list, /* dummy column aliased by result set name */
        '' as o_custom_info_json /* unicode string */
    FROM <Table name>
    */

	
	declare @p_inputparam_xml xml, @p_skip varchar(10), @p_take varchar(10),
	@p_request_status_filter_string varchar(50), @p_request_status_filter varchar(50),
	@p_request_status varchar(50), @p_offset_count int, @p_rowcount int, 
	@p_employee_id varchar(30),@p_user_group_id varchar(30), @p_date_type_filter varchar(2)

	declare @o_header_udf_char_1 bit,	@o_header_udf_char_2 bit,	@o_header_udf_char_3 bit,	@o_header_udf_char_4  bit,
			@o_header_udf_char_5 bit,	@o_header_udf_char_6 bit,	@o_header_udf_char_7 bit,	@o_header_udf_char_8  bit,
			@o_header_udf_char_9 bit,	@o_header_udf_char_10 bit,	
			@o_header_udf_bit_1 bit,	@o_header_udf_bit_2 bit,	@o_header_udf_bit_3 bit,	@o_header_udf_bit_4 bit,
			@o_header_udf_bit_5 bit,	@o_header_udf_bit_6 bit,	@o_header_udf_bit_7 bit,	@o_header_udf_bit_8 bit,
			@o_header_udf_bit_9 bit,	@o_header_udf_bit_10 bit,
			@o_header_udf_float_1 bit,	@o_header_udf_float_2 bit,	@o_header_udf_float_3 bit,	@o_header_udf_float_4 bit,
			@o_header_udf_float_5 bit,	@o_header_udf_float_6 bit,	@o_header_udf_float_7 bit,	@o_header_udf_float_8 bit,
			@o_header_udf_float_9 bit,	@o_header_udf_float_10 bit,
			@o_header_udf_date_1 bit,	@o_header_udf_date_2 bit,	@o_header_udf_date_3  bit,	@o_header_udf_date_4  bit,
			@o_header_udf_date_5 bit,	@o_header_udf_date_6 bit,	@o_header_udf_date_7  bit,	@o_header_udf_date_8  bit,
			@o_header_udf_date_9 bit,	@o_header_udf_date_10 bit,
			@o_header_udf_analysis_code1 bit,	@o_header_udf_analysis_code2 bit,	@o_header_udf_analysis_code3 bit,
			@o_header_udf_analysis_code4 bit,	@o_header_udf_analysis_code5 bit,	@o_header_udf_analysis_code6 bit,
			@o_header_udf_analysis_code7 bit,	@o_header_udf_analysis_code8 bit,	@o_header_udf_analysis_code9 bit,
			@o_header_udf_analysis_code10 bit

	select @p_employee_id = employee_id,
		@p_user_group_id = user_group_id 
	from users
	where company_id = @i_client_id
		and country_code = @i_country_code
		and user_id = @i_user_id

	create table #inputparams
	(
		paramname varchar(50) not null,
		paramval varchar(50) null
	)

	create table #input_params_multival
	(
		paramname varchar(50) not null,
		paramval varchar(50) not null
	)

	set @p_inputparam_xml = CAST(@i_inputparam_xml as XML)

	insert #inputparams
	(
		paramname, 
		paramval
	)
	
	select nodes.value('local-name(.)', 'varchar(50)'),
		nodes.value('(.)[1]', 'varchar(50)')
	from @p_inputparam_xml.nodes('/inputparam/*') as Tbl(nodes)

	select @p_date_type_filter = paramval from #inputparams where paramname = 'date_type_filter'
	
	if @p_date_type_filter is null set @p_date_type_filter = '%'

	update #inputparams
	set paramval = null 
	where paramval = 'ALL'
		or paramval = ''

	select @p_skip = paramval from #inputparams where paramname = 'skip'

	select @p_take = paramval from #inputparams where paramname = 'take'

	select @p_request_status_filter_string = '%',@p_request_status_filter ='%'
    
    select @p_request_status_filter_string = paramval,
			@p_request_status_filter = paramval
    from #inputparams
    where paramname = 'request_status_filter'
      and paramval != '%'

	if @p_request_status_filter_string != '%'
    begin
	
		 if charindex(',',@p_request_status_filter_string) = 0 and @p_request_status_filter_string != ''
		 begin
			set @p_request_status = @p_request_status_filter_string
			set @p_request_status_filter_string = ''
		 end
		 else
		 begin
			set @p_request_status = substring( @p_request_status_filter_string, 1, charindex(',',@p_request_status_filter_string)-1)
			set @p_request_status_filter_string = substring(@p_request_status_filter_string, charindex(',',@p_request_status_filter_string)+1,LEN(@p_request_status_filter_string))
				
		 end
						  
		 while (@p_request_status != '')
		 begin
					  
		  insert #input_params_multival
		  (
			paramname, paramval
		  )
		  select 'request_status_filter', @p_request_status
							
		  if charindex(',',@p_request_status_filter_string) = 0 
		  begin
			set @p_request_status = @p_request_status_filter_string
			set @p_request_status_filter_string = ''
		  end
		  else
		  begin
			set @p_request_status = substring( @p_request_status_filter_string, 1, charindex(',',@p_request_status_filter_string)-1)
			set @p_request_status_filter_string = substring(@p_request_status_filter_string, charindex(',',@p_request_status_filter_string)+1,LEN(@p_request_status_filter_string))
		  end
							
		 end
						 	
    end

	if 	@p_skip = '%' select @p_skip = 0
	if  @p_take = '%' select @p_take = 0
	
	select @p_offset_count = @p_skip

	if @p_take = 0
		select @p_rowcount = count(*) 
		from ancillary_request_register
		where company_id = @i_client_id
			and country_code = @i_country_code
	else
		select @p_rowcount = cast(@p_take as int)

	execute sp_retrieve_applicable_ancillary_udfs @i_client_id , @i_country_code ,  @i_session_id , 
				@i_user_id ,  @i_locale_id , 'ANCILLARY_REGISTER','TADA', 
				@o_header_udf_char_1 OUTPUT, @o_header_udf_char_2 OUTPUT, @o_header_udf_char_3 OUTPUT,	
				@o_header_udf_char_4  OUTPUT, @o_header_udf_char_5 OUTPUT, @o_header_udf_char_6 OUTPUT,	
				@o_header_udf_char_7  OUTPUT, @o_header_udf_char_8 OUTPUT, @o_header_udf_char_9 OUTPUT, 
				@o_header_udf_char_10 OUTPUT,
				@o_header_udf_bit_1 OUTPUT,@o_header_udf_bit_2 OUTPUT,@o_header_udf_bit_3 OUTPUT,
				@o_header_udf_bit_4 OUTPUT,@o_header_udf_bit_5 OUTPUT,@o_header_udf_bit_6 OUTPUT,
				@o_header_udf_bit_7 OUTPUT,@o_header_udf_bit_8 OUTPUT,@o_header_udf_bit_9 OUTPUT,
				@o_header_udf_bit_10 OUTPUT,
				@o_header_udf_float_1 OUTPUT, @o_header_udf_float_2 OUTPUT, @o_header_udf_float_3 OUTPUT,
				@o_header_udf_float_4 OUTPUT, @o_header_udf_float_5 OUTPUT, @o_header_udf_float_6 OUTPUT,
				@o_header_udf_float_7 OUTPUT, @o_header_udf_float_8 OUTPUT, @o_header_udf_float_9 OUTPUT,				
				@o_header_udf_float_10 OUTPUT,	
				@o_header_udf_date_1 OUTPUT, @o_header_udf_date_2 OUTPUT, @o_header_udf_date_3 OUTPUT,	
				@o_header_udf_date_4 OUTPUT, @o_header_udf_date_5 OUTPUT, @o_header_udf_date_6 OUTPUT,	
				@o_header_udf_date_7 OUTPUT, @o_header_udf_date_8 OUTPUT, @o_header_udf_date_9 OUTPUT,	
				@o_header_udf_date_10 OUTPUT,
				@o_header_udf_analysis_code1 OUTPUT, @o_header_udf_analysis_code2 OUTPUT,
				@o_header_udf_analysis_code3 OUTPUT, @o_header_udf_analysis_code4 OUTPUT,
				@o_header_udf_analysis_code5 OUTPUT, @o_header_udf_analysis_code6 OUTPUT,
				@o_header_udf_analysis_code7 OUTPUT, @o_header_udf_analysis_code8 OUTPUT,
				@o_header_udf_analysis_code9 OUTPUT, @o_header_udf_analysis_code10 OUTPUT

	select '' as custom_info_list,
		'{' +
			'"total":"'+ convert(varchar(12), count(*) over()) +'",'+
			'"request_ref_no":"'+isnull(a.request_ref_no,'')+'",'+ 
			'"request_category":"'+isnull(a.request_category,'')+'",'+
			'"request_category_desc":"'+ (
				case (select 1 from code_table_mlingual_translation f
				where f.company_id = @i_client_id
					and f.country_code = @i_country_code
					and f.locale_id = @i_locale_id
					and f.code_type = 'ANCILLARYCATG'
					and f.code = request_category)
				when 1 then
				(select e.long_description 
				from code_table_mlingual_translation e
				where e.company_id = @i_client_id
					and e.country_code = @i_country_code
					and e.locale_id = @i_locale_id
					and e.code_type = 'ANCILLARYCATG'
					and e.code = request_category)
				else
				(select g.long_description from code_table_mlingual_translation g
				where g.company_id = @i_client_id
					and g.country_code = @i_country_code
					and g.locale_id = 'ALL'
					and g.code_type = 'ANCILLARYCATG'
					and g.code = request_category)
				end) +'",'+
			'"request_type":"'+isnull(a.request_type,'')+'",'+
			'"request_type_desc":"'+ (
				case (select 1 from code_table_mlingual_translation f
				where f.company_id = @i_client_id
					and f.country_code = @i_country_code
					and f.locale_id = @i_locale_id
					and f.code_type = 'ANCILLARYTYPE'
					and f.code = request_type)
				when 1 then
				(select e.long_description 
				from code_table_mlingual_translation e
				where e.company_id = @i_client_id
					and e.country_code = @i_country_code
					and e.locale_id = @i_locale_id
					and e.code_type = 'ANCILLARYTYPE'
					and e.code = request_type)
				else
				(select g.long_description from code_table_mlingual_translation g
				where g.company_id = @i_client_id
					and g.country_code = @i_country_code
					and g.locale_id = 'ALL'
					and g.code_type = 'ANCILLARYTYPE'
					and g.code = request_type)
				end) +'",'+
			'"request_status":"'+isnull(a.request_status,'')+'",'+
			'"request_status_desc":"'+
	   			isnull(case (select 1 from code_table_mlingual_translation f
						where f.company_id = @i_client_id
							and f.country_code = @i_country_code
							and f.locale_id = @i_locale_id
							and f.code_type = 'ANCILLARYSTATUS'
							and f.code = a.request_status)
					when 1 then
					(select e.long_description 
						from code_table_mlingual_translation e
					where e.company_id = @i_client_id
						and e.country_code = @i_country_code
						and e.locale_id = @i_locale_id
						and e.code_type = 'ANCILLARYSTATUS'
						and e.code = a.request_status)
					else
					(select g.long_description from code_table_mlingual_translation g
					where g.company_id = @i_client_id
						and g.country_code = @i_country_code
						and g.locale_id = 'ALL'
						and g.code_type = 'ANCILLARYSTATUS'
						and g.code = a.request_status)
					end ,'')+
				'",'+
			'"requirement":"'+isnull(a.requirement,'')+'",'+
			'"billable_nonbillable_ind":"'+isnull(a.billable_nonbillable_ind,'')+'",'+
			'"workflow_stage_no":"' + isnull(convert(varchar(3), a.request_wf_stage_no),'') + '",' +
			'"workflow_stage_no_desc":"' + 
				isnull((
					select x.description 
					from workflow_stage_master x
					where x.company_id = @i_client_id
						and x.country_code = @i_country_code
						and x.transaction_type_code = 'ANCILLARY'
						and x.request_category = a.request_category
						and x.workflow_stage_no = a.request_wf_stage_no ), '') + 
			'",' +
			'"priority_cd":"'+isnull(a.priority_code,'')+'",'+
			'"company_location_code":"'+isnull(a.company_location_code,'')+'",'+
			'"org_level_no":"'+ isnull(cast(a.organogram_level_no as varchar(3)),'')+'",'+
			'"org_level_code":"'+isnull(a.organogram_level_code,'') +'",'+
			'"created_by_employee_id":"'+isnull(a.created_by_employee_id,'')+'",'+
			'"created_by_employee_name":"'+ISNULL(( select c1.first_name+' '+c1.last_name
				from employee c1
				where c1.company_id = @i_client_id
					and c1.country_code = @i_country_code
					and c1.employee_id = a.created_by_employee_id),'')+'",'+
			'"created_on_date":"'+isnull(CONVERT(varchar(10),a.created_on_date,120),'')+'",'+
			'"created_on_hour":"'+isnull(substring(CONVERT(varchar(10),a.created_on_date,108),1,2),'')+'",'+
			'"created_on_minute":"'+isnull(substring(CONVERT(varchar(10),a.created_on_date,108),4,2),'')+'",'+ 
			'"current_assignee_emp_id":"'+
				isnull( (select b.resource_emp_id
				 from ancillary_request_workflow_assignment b
				 where b.company_id = @i_client_id
				   and b.country_code = @i_country_code
				   and b.request_ref_no = a.request_ref_no
				   and b.current_assignee_ind = 1 ), '')
			   +'",'+
			'"gross_amount":"'+ isnull((select convert(nvarchar(30),(cast(sum(isnull(udf_float_4,0)) as numeric (30))))
						from ancillary_request_register_actions b
						where b.company_id = @i_client_id
							and b.country_code = @i_country_code
							and b.request_ref_no = a.request_ref_no), '0')
			   +'",'+
			'"call_ref_no":"'+
				isnull( (select b.call_ref_no
				 from call_register_actions b
				 where b.company_id = @i_client_id
				   and b.country_code = @i_country_code
				   and action_category = 'LINK'
				   and action_type = 'TADAAGAINSTCALL'
				   and b.sys_gen_call_ref_no = a.request_ref_no), '')
			   +'",'+
			 (case @o_header_udf_char_1 when 1 then '"udf_char_1":"'+ISNULL(a.udf_char_1,'')+'",' else '' end)+
			   (case @o_header_udf_char_2 when 1 then '"udf_char_2":"'+ISNULL(a.udf_char_2,'')+'",' else '' end)+
			   (case @o_header_udf_char_3 when 1 then '"udf_char_3":"'+ISNULL(a.udf_char_3,'')+'",' else '' end)+
			   (case @o_header_udf_char_4 when 1 then '"udf_char_4":"'+ISNULL(a.udf_char_4,'')+'",' else '' end)+
			   (case @o_header_udf_bit_1 when 1 then '"udf_bit_1":"'+cast(ISNULL(a.udf_bit_1,0) as varchar(1))+'",' else '' end)+
			   (case @o_header_udf_bit_2 when 1 then '"udf_bit_2":"'+cast(ISNULL(a.udf_bit_2,0) as varchar(1))+'",' else '' end)+
			   (case @o_header_udf_bit_3 when 1 then '"udf_bit_3":"'+cast(ISNULL(a.udf_bit_3,0) as varchar(1))+'",' else '' end)+
			   (case @o_header_udf_bit_4 when 1 then '"udf_bit_4":"'+cast(ISNULL(a.udf_bit_4,0) as varchar(1))+'",' else '' end)+
			   (case @o_header_udf_float_1 when 1 then '"udf_float_1":"'+CAST(isnull(cast(a.udf_float_1 as numeric(14,2)),0) as varchar(14))+'",' else '' end)+
			   (case @o_header_udf_float_2 when 1 then '"udf_float_2":"'+CAST(isnull(cast(a.udf_float_2 as numeric(14,2)),0) as varchar(14))+'",' else '' end)+
			   (case @o_header_udf_float_3 when 1 then '"udf_float_3":"'+CAST(isnull(cast(a.udf_float_3 as numeric(14,2)),0) as varchar(14))+'",' else '' end)+
			   (case @o_header_udf_float_4 when 1 then '"udf_float_4":"'+CAST(isnull(cast(a.udf_float_4 as numeric(14,2)),0) as varchar(14))+'",' else '' end)+
			   (case @o_header_udf_date_1 when 1 then 
				   '"udf_date_1":"'+isnull(convert(varchar(10), a.udf_date_1, 120),'')+'",'+
				   '"udf_date_1_hour":"'+isnull(substring(CONVERT(varchar(10), a.udf_date_1, 108),1,2),'')+'",'+
				   '"udf_date_1_minute":"'+isnull(substring(CONVERT(varchar(10), a.udf_date_1, 108),4,2),'')+'",'       
				else '' end)+
			   (case @o_header_udf_date_2 when 1 then 
				   '"udf_date_2":"'+isnull(convert(varchar(10), a.udf_date_2, 120),'')+'",'+
				   '"udf_date_2_hour":"'+isnull(substring(CONVERT(varchar(10), a.udf_date_2, 108),1,2),'')+'",'+
					'"udf_date_2_minute":"'+isnull(substring(CONVERT(varchar(10), a.udf_date_2, 108),4,2),'')+'",'       
				else '' end)+
			   (case @o_header_udf_date_3 when 1 then
					'"udf_date_3":"'+isnull(convert(varchar(10), a.udf_date_3, 120),'')+'",'+
					'"udf_date_3_hour":"'+isnull(substring(CONVERT(varchar(10), a.udf_date_3, 108),1,2),'')+'",'+
					'"udf_date_3_minute":"'+isnull(substring(CONVERT(varchar(10), a.udf_date_3, 108),4,2),'')+'",'       
				 else '' end)+
			   (case @o_header_udf_date_4 when 1 then 
					'"udf_date_4":"'+isnull(convert(varchar(10), a.udf_date_4, 120),'')+'",'+
					'"udf_date_4_hour":"'+isnull(substring(CONVERT(varchar(10), a.udf_date_4, 108),1,2),'')+'",'+
					'"udf_date_4_minute":"'+isnull(substring(CONVERT(varchar(10), a.udf_date_4, 108),4,2),'')+'",' 
				else '' end)+
			   (case @o_header_udf_analysis_code1 when 1 then '"udf_analysis_code1":"'+ISNULL(a.udf_analysis_code1,'')+'",' else '' end)+
			   (case @o_header_udf_analysis_code2 when 1 then '"udf_analysis_code2":"'+ISNULL(a.udf_analysis_code2,'')+'",' else '' end)+
			   (case @o_header_udf_analysis_code3 when 1 then '"udf_analysis_code3":"'+ISNULL(a.udf_analysis_code3,'')+'",' else '' end)+
			   (case @o_header_udf_analysis_code4 when 1 then '"udf_analysis_code4":"'+ISNULL(a.udf_analysis_code4,'')+'",' else '' end)+
			'"rec_tstamp":"'+isnull(cast(convert(uniqueidentifier,cast(a.last_update_timestamp as binary)) as varchar(36)),'')+'"'+
			'}'
		as o_custom_info_json
	from ancillary_request_register a 
		where a.company_id = @i_client_id
		and a.country_code = @i_country_code
		and isnull(( a.request_ref_no),'') like 
		isnull( (select '%'+paramval+'%' from #inputparams where paramname = 'request_ref_no_filter') , a.request_ref_no)
		and isnull(( a.request_category),'') like 
		isnull( (select '%'+paramval+'%' from #inputparams where paramname = 'request_category_filter') , a.request_category)
		and isnull(( a.request_type),'') like 
		isnull( (select '%'+paramval+'%' from #inputparams where paramname = 'request_type_filter') , a.request_type)
		and (isnull(@p_request_status_filter,'%') = '%' 
		or  
		(a.request_status in  (select paramval from #input_params_multival where paramname = 'request_status_filter')
			))

	order by a.created_on_date desc

    SET NOCOUNT OFF;
END
