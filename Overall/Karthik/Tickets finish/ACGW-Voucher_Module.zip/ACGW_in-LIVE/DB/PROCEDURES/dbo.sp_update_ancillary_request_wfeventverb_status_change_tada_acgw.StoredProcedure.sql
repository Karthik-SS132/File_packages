
if exists (select 1 from sys.procedures where name = 'sp_update_ancillary_request_wfeventverb_status_change_tada_acgw')
begin
/****** Object:  StoredProcedure [dbo].[sp_update_ancillary_request_wfeventverb_status_change_tada_acgw]    Script Date: 6/7/2022 2:46:50 PM ******/
DROP PROCEDURE [dbo].[sp_update_ancillary_request_wfeventverb_status_change_tada_acgw]
end

/****** Object:  StoredProcedure [dbo].[sp_update_ancillary_request_wfeventverb_status_change_tada_acgw]    Script Date: 20/04/2023 18:28:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_update_ancillary_request_wfeventverb_status_change_tada_acgw]
    @i_client_id [uddt_client_id], 
    @i_country_code [uddt_country_code], 
    @i_session_id [sessionid], 
    @i_user_id [userid], 
    @i_locale_id [uddt_locale_id], 
    @i_request_ref_no [uddt_nvarchar_20], 
    @i_channel_id [uddt_varchar_20], 
    @i_wfeventverb_id [uddt_varchar_60], 
    @i_event_date [uddt_date], 
    @i_event_hour [uddt_hour], 
    @i_event_minute [uddt_minute], 
    @i_from_wf_stage_no [uddt_tinyint], 
    @i_to_wf_stage_no [uddt_tinyint], 
    @i_from_wf_status [uddt_varchar_2], 
    @i_to_wf_status [uddt_varchar_2], 
    @i_by_employee_id [uddt_employee_id],
    @i_to_employee_id_string [uddt_nvarchar_255], 
    @i_reason_code [uddt_nvarchar_50], 
    @i_comments [uddt_nvarchar_1000], 
    @i_lattitude_value [uddt_varchar_10], 
    @i_longitude_value [uddt_varchar_10], 
    @i_inputparam_xml1 [uddt_nvarchar_max], 
    @i_inputparam_xml2 [uddt_nvarchar_max], 
    @i_inputparam_xml3 [uddt_nvarchar_max], 
    @i_attachment_xml [uddt_nvarchar_max], 
    @i_rec_tstamp [uddt_uid_timestamp], 
    @i_save_mode [uddt_varchar_1], 
    @o_childproc_execution_status [uddt_varchar_10] OUTPUT,
    @o_childproc_execution_error_message [uddt_nvarchar_200] OUTPUT
AS
BEGIN
    /*
     * Function to save call status change for predefined workflow events.
     */
    -- SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
    SET NOCOUNT ON;

		declare @p_request_category varchar(10),
		@p_request_type nvarchar(10),
		@p_from_wf_status varchar(3),
		@p_to_wf_status varchar(3),
		@p_by_employee_id nvarchar(12),
		@p_from_wf_stage_no varchar(3), 
		@p_to_wf_stage_no varchar(3),
		@p_attachment_xml xml, @p_event_id int,
		@p_event_date datetimeoffset(7),
		@p_current_wf_stage_no tinyint,
		@p_current_wf_status varchar(2),
		@p_organogram_level_no tinyint,
		@p_organogram_level_code nvarchar(15),
		@p_company_location_code nvarchar(8),
		@p_attachment_file_path nvarchar(30),
		@p_doc_handle int

		declare @p_assigned_to_employee_id nvarchar(12), @p_id_type varchar(2), @p_id_org_level_no tinyint, 
		@p_id_code nvarchar(30), @p_gross_amount decimal(20,4)

		select @o_childproc_execution_error_message = '',@o_childproc_execution_status = ''
		
		create table #attachment_list
		(
			file_category varchar(2) null,
			file_type varchar(2) null,
			file_name nvarchar(60) null,
			closure_report_ind bit null  
		)
  
		EXEC sp_xml_preparedocument @p_doc_handle OUTPUT, @i_attachment_xml;

		insert #attachment_list
		(file_category, file_type, file_name, closure_report_ind)
		SELECT file_category, file_type, FILE_NAME, closure_report_indicator
		FROM OPENXML (@p_doc_handle, '/attachment_xml/attachment',2)
		WITH (file_category  varchar(2),
			file_type varchar(2),
			file_name nvarchar(60),
			closure_report_indicator varchar(1));

		update #input_params
		set paramval = null 
		where paramval = 'ALL'
		or paramval = ''

		create table #applicable_custom_fields
		(
			field_type varchar(50) not null,
			applicable bit not null
		)
	
		insert #applicable_custom_fields
		(field_type, applicable)
		select field_type, applicable
		from product_customization_data_field_reference
		where company_id = @i_client_id
		  and country_code = @i_country_code
		  and information_type = 'ANCILLARY_REGISTER'
		  and information_subtype = 'TADA'
			 	
		select @p_request_category = request_category,
			@p_request_type = request_type,
			@p_current_wf_stage_no = request_wf_stage_no,
			@p_current_wf_status = request_status,
			@p_organogram_level_no = organogram_level_no,
			@p_organogram_level_code = organogram_level_code,
			@p_company_location_code = company_location_code		
		from ancillary_request_register
		where company_id = @i_client_id
		  and country_code = @i_country_code
		  and request_ref_no = @i_request_ref_no

		select @p_gross_amount = sum(isnull(udf_float_4,0))
		from ancillary_request_register_actions
		where company_id = @i_client_id
		  and country_code = @i_country_code
		  and request_ref_no = @i_request_ref_no
		  
		if @p_gross_amount is null set @p_gross_amount = 0
    
		if @i_wfeventverb_id != 'STATUSCHANGE'
			if exists(select 1 from workflow_eventverb_list
						where company_id = @i_client_id
						  and country_code = @i_country_code
						  and transaction_type_code  = 'ANCILLARY'
						  and request_category = @p_request_category
						  and request_type in ('ALL', @p_request_type)
						  and eventverb_id = @i_wfeventverb_id
						  and from_workflow_stage = @p_current_wf_stage_no
						  and from_status = @p_current_wf_status
						  and lcl_value != 'NA')
			begin
				select  @p_from_wf_stage_no = from_workflow_stage,
						@p_from_wf_status =  from_status,
						@p_to_wf_stage_no = to_workflow_stage,
						@p_to_wf_status =   to_status 
				from workflow_eventverb_list
				where @p_gross_amount between cast(lcl_value as numeric) and cast(ucl_value as numeric)
				  and company_id = @i_client_id
				  and country_code = @i_country_code
				  and transaction_type_code  = 'ANCILLARY'
				  and request_category = @p_request_category
				  and request_type in ('ALL', @p_request_type)
				  and eventverb_id = @i_wfeventverb_id
				  and from_workflow_stage = @p_current_wf_stage_no
				  and from_status = @p_current_wf_status
			end
			else
			begin
				select  @p_from_wf_stage_no = from_workflow_stage,
						@p_from_wf_status =  from_status,
						@p_to_wf_stage_no = to_workflow_stage,
						@p_to_wf_status =   to_status 
				from workflow_eventverb_list
				where company_id = @i_client_id
				  and country_code = @i_country_code
				  and transaction_type_code  = 'ANCILLARY'
				  and request_category = @p_request_category
				  and request_type in ('ALL', @p_request_type)
				  and eventverb_id = @i_wfeventverb_id
				  and from_workflow_stage = @p_current_wf_stage_no
				  and from_status = @p_current_wf_status
			end
		else /* STATUSCHANGE */
			if exists (select 1 from workflow_status_link
						where company_id = @i_client_id
						  and country_code = @i_country_code
						  and transaction_type_code  = 'ANCILLARY'
						  and request_category = @p_request_category
						  and request_type in ('ALL', @p_request_type)
						  and from_workflow_stage = @i_from_wf_stage_no 
						  and from_status = @i_from_wf_status
						  and to_workflow_stage = @i_to_wf_stage_no
						  and to_status = @i_to_wf_status
						  and lcl_value != 'NA')
			begin
				select  @p_from_wf_stage_no = from_workflow_stage,
						@p_from_wf_status =  from_status,
						@p_to_wf_stage_no = to_workflow_stage,
						@p_to_wf_status =   to_status 
				from workflow_status_link
				where @p_gross_amount between cast(lcl_value as numeric) and cast(ucl_value as numeric)
				  and company_id = @i_client_id
				  and country_code = @i_country_code
				  and transaction_type_code  = 'ANCILLARY'
				  and request_category = @p_request_category
				  and request_type in ('ALL', @p_request_type)
				  and from_workflow_stage = @i_from_wf_stage_no 
				  and from_status = @i_from_wf_status
				  and to_workflow_stage = @i_to_wf_stage_no
				  and to_status = @i_to_wf_status
			end
			else
			begin
				select  @p_from_wf_stage_no = from_workflow_stage,
						@p_from_wf_status =  from_status,
						@p_to_wf_stage_no = to_workflow_stage,
						@p_to_wf_status =   to_status 
				from workflow_status_link
				where company_id = @i_client_id
				  and country_code = @i_country_code
				  and transaction_type_code  = 'ANCILLARY'
				  and request_category = @p_request_category
				  and request_type in ('ALL', @p_request_type)
				  and from_workflow_stage = @i_from_wf_stage_no 
				  and from_status = @i_from_wf_status
				  and to_workflow_stage = @i_to_wf_stage_no
				  and to_status = @i_to_wf_status
			end
				   
		/* Check validity of the Ancillary */
		
		if not exists ( select 1 from ancillary_request_register
						where company_id = @i_client_id
						  and country_code = @i_country_code
						  and request_ref_no = @i_request_ref_no
						  and request_wf_stage_no = @i_from_wf_stage_no
						  and request_status = @i_from_wf_status)
		begin
 			select @o_childproc_execution_status = 'FAILURE',
 				   @o_childproc_execution_error_message = 'Invalid Ancillary Reference No'
			return
		end    
		
		/* Validate Event Verb */
		
		if @i_wfeventverb_id != 'STATUSCHANGE' 
		and not exists ( select 1 from workflow_eventverb_list
			where company_id = @i_client_id
			   and country_code = @i_country_code
			   and transaction_type_code  = 'ANCILLARY'
			   and request_category in ('ALL',@p_request_category)
			   and request_type in ('ALL', @p_request_type)
			   and from_workflow_stage = @p_from_wf_stage_no 
			   and from_status = @p_from_wf_status
			   and to_workflow_stage = @p_to_wf_stage_no
			   and to_status = @p_to_wf_status
			   and eventverb_id = @i_wfeventverb_id
			)
		begin
			select @o_childproc_execution_status = 'FAILURE',
				   @o_childproc_execution_error_message = 'Invalid Workflow Action'
			return
		end
		 
		if @i_wfeventverb_id = 'STATUSCHANGE' and not exists ( select 1 from workflow_status_link
			where company_id = @i_client_id
				and country_code = @i_country_code
				and transaction_type_code  = 'ANCILLARY'
				and request_category = @p_request_category
				and request_type in ('ALL', @p_request_type)
				and from_workflow_stage = @p_from_wf_stage_no 
				and from_status = @p_from_wf_status
				and to_workflow_stage = @p_to_wf_stage_no
				and to_status = @p_to_wf_status
			)
		begin
		 	select @o_childproc_execution_status = 'FAILURE',
 				   @o_childproc_execution_error_message = 'Invalid Workflow Action'
			return
		end
		  
		select @p_by_employee_id = employee_id
		from users
		where company_id = @i_client_id
			and country_code = @i_country_code
			and user_id = @i_user_id
	
		if @i_channel_id = 'MOBILE'
		begin	
		  set @p_event_date = (select CONVERT(datetimeoffset, @i_event_date + ' ' + @i_event_hour + ':' + @i_event_minute + ':00', 120))
		end
		else
		begin
			set @p_event_date = SYSDATETIMEOFFSET()
		end
		  						  
		set @p_event_id = @@IDENTITY
		
		/* Update attachments - multi attachment insert - pending */
		
		if exists ( select 1 from #attachment_list)
		begin	
			
			select @p_attachment_file_path = code
			from code_table
			where company_id = @i_client_id
			  and country_code = @i_country_code
			  and code_type = 'ANCILLARYATTACHPATH'
			  
			if not exists ( select 1 from category_type_link b, #attachment_list c
						     where b.company_id = @i_client_id
						       and b.country_code = @i_country_code
						       and b.link_type = 'FA'
						       and b.category_code_type = 'FILECATG'
						       and b.category_code_value = c.file_category
						       and b.type_code_type = 'FILEEXTNALLOWED'
						       and b.type_code_value = 
						           substring(ltrim(rtrim(c.file_name)),len(ltrim(rtrim(c.file_name))) - charindex('.', reverse(ltrim(rtrim(c.file_name))))+1, LEN(ltrim(rtrim(c.file_name)))))
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failure: Unsupported File Extension'
				return
			end
						 			
			insert ancillary_request_user_attachments
			(
			  company_id, country_code, request_ref_no,
			  event_id,
			  attachment_file_category, attachment_file_type, 
			  attachment_file_name, attachment_file_path,last_update_id
			)
			 select @i_client_id, @i_country_code,
				   @i_request_ref_no,
				   @p_event_id, 
					file_category, file_type, file_name, 
					@p_attachment_file_path, @i_user_id
			 from #attachment_list

			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed to update ancillary user attachments'
				return
			end

			update ancillary_request_user_attachments
			set attachment_file_id = attachment_file_category+attachment_file_type+REPLACE(str(attachment_file_sysgen_id,5,0),' ','0')
			from #attachment_list b
			where company_id = @i_client_id
			  and country_code = @i_country_code
			  and request_ref_no = @i_request_ref_no
			  and attachment_file_name = b.file_name 
			
			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed to update ancillary user attachments'
				return
			end
		  
		end

		if @i_wfeventverb_id = 'TADASUBMITFORAPPROVAL'
		begin

			if @p_to_wf_stage_no = 1 and @p_to_wf_status = 'WA'
			begin

				select @p_id_type = id_type, 
						@p_id_org_level_no = id_org_level_no,
						@p_id_code = id_code
				from workflow_approval_profile
				where company_id = @i_client_id
					and country_code = @i_country_code
					and access_for_event = 'APPROVE-TADA'
					and approval_order = 1
					and level1_code = 'ALL'
					and level2_code = 'ALL'
					and level3_code = (select organogram_level_code from employee where company_id = @i_client_id and country_code = @i_country_code and employee_id = @p_by_employee_id)

				if @p_id_type = 'EA'
				begin
					select @p_assigned_to_employee_id = @p_id_code 
				end

				if isnull(@p_assigned_to_employee_id,'') = ''	
				begin
					select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Invalid Assignee'
				return
				end 

				insert ancillary_request_workflow_assignment
				(
					company_id,
					country_code,
					request_ref_no,
					resource_emp_id,
					assigned_on_date,
					current_assignee_ind,
					last_update_id
				)
				select @i_client_id, @i_country_code, @i_request_ref_no,
						@p_assigned_to_employee_id, SYSDATETIMEOFFSET(),
						1, @i_user_id

				if @@ROWCOUNT = 0
				begin
					select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary Workflow Assignment'
					return
				end

			end

			update ancillary_request_register	
			set request_wf_stage_no = @p_to_wf_stage_no,
				request_status = @p_to_wf_status,
				last_update_id = @i_user_id
			where company_id = @i_client_id
				and country_code = @i_country_code
				and request_ref_no = @i_request_ref_no


			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed updating ancillary register'
				return
			end
	
			set @p_event_date = SYSDATETIMEOFFSET()
					
			insert ancillary_request_status_event_log
			(
				company_id, country_code, request_ref_no,
				channel_id,
				eventverb_id,
				from_wf_stage_no,
				to_wf_stage_no,
				event_date, to_status, from_status,
				by_employee_id, 
				to_employee_id_string,
				comments, 
				reason_code,
				last_update_id
			)
			select @i_client_id, @i_country_code, @i_request_ref_no,
					@i_channel_id,
					@i_wfeventverb_id,
					@p_from_wf_stage_no,
					@p_to_wf_stage_no,
					@p_event_date, 
					@p_to_wf_status, @p_from_wf_status,
					@i_by_employee_id, 
					@p_assigned_to_employee_id,
					case @i_comments when '' then null else @i_comments end,
					case @i_reason_code when '' then null else @i_reason_code end,
					@i_user_id

			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary Event Log'
				return
			end
		    
		end	

		if @i_wfeventverb_id = 'TADAAPPROVE'
		begin

			if @p_to_wf_stage_no = 2 and @p_to_wf_status = 'A1'
			begin

				select @p_id_type = id_type, 
						@p_id_org_level_no = id_org_level_no,
						@p_id_code = id_code
				from workflow_approval_profile
				where company_id = @i_client_id
					and country_code = @i_country_code
					and access_for_event = 'APPROVE-TADA'
					and approval_order = 2
					and level1_code = 'ALL'
					and level2_code = 'ALL'
					and level3_code = (select organogram_level_code from employee where company_id = @i_client_id and country_code = @i_country_code and employee_id = @p_by_employee_id)

				if @p_id_type = 'EA'
				begin
					select @p_assigned_to_employee_id = @p_id_code 
				end

				if isnull(@p_assigned_to_employee_id,'') = ''	
				begin
					select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Invalid Assignee'
				return
				end 

				update ancillary_request_workflow_assignment
				set current_assignee_ind = 0
  				where company_id = @i_client_id
					and country_code = @i_country_code
					and request_ref_no = @i_request_ref_no
					and current_assignee_ind = 1
				
				if @@ROWCOUNT = 0
				begin
					select @o_childproc_execution_status = 'FAILURE',
 							@o_childproc_execution_error_message = 'Failed insert into Ancillary workflow assignment'
					return
				end

				insert ancillary_request_workflow_assignment
				(
					company_id,
					country_code,
					request_ref_no,
					resource_emp_id,
					assigned_on_date,
					current_assignee_ind,
					last_update_id
				)
				select @i_client_id, @i_country_code, @i_request_ref_no,
						@p_assigned_to_employee_id, SYSDATETIMEOFFSET(),
						1, @i_user_id

				if @@ROWCOUNT = 0
				begin
					select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary Workflow Assignment'
					return
				end

			end

			if @p_to_wf_stage_no = 2 and @p_to_wf_status = 'A2'
			begin

				select @p_id_type = id_type, 
						@p_id_org_level_no = id_org_level_no,
						@p_id_code = id_code
				from workflow_approval_profile
				where company_id = @i_client_id
					and country_code = @i_country_code
					and access_for_event = 'APPROVE-TADA'
					and approval_order = 3
					and level1_code = 'ALL'
					and level2_code = 'ALL'

				if @p_id_type = 'EA'
				begin
					select @p_assigned_to_employee_id = @p_id_code 
				end

				if isnull(@p_assigned_to_employee_id,'') = ''	
				begin
					select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Invalid Assignee'
				return
				end 

				update ancillary_request_workflow_assignment
				set current_assignee_ind = 0
  				where company_id = @i_client_id
					and country_code = @i_country_code
					and request_ref_no = @i_request_ref_no
					and current_assignee_ind = 1
				
				if @@ROWCOUNT = 0
				begin
					select @o_childproc_execution_status = 'FAILURE',
 							@o_childproc_execution_error_message = 'Failed insert into Ancillary workflow assignment'
					return
				end

				insert ancillary_request_workflow_assignment
				(
					company_id,
					country_code,
					request_ref_no,
					resource_emp_id,
					assigned_on_date,
					current_assignee_ind,
					last_update_id
				)
				select @i_client_id, @i_country_code, @i_request_ref_no,
						@p_assigned_to_employee_id, SYSDATETIMEOFFSET(),
						1, @i_user_id

				if @@ROWCOUNT = 0
				begin
					select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary Workflow Assignment'
					return
				end

			end

			if @p_to_wf_stage_no = 2 and @p_to_wf_status = 'A3'
			begin

				select @p_id_type = id_type, 
						@p_id_org_level_no = id_org_level_no,
						@p_id_code = id_code
				from workflow_approval_profile
				where company_id = @i_client_id
					and country_code = @i_country_code
					and access_for_event = 'APPROVE-TADA'
					and approval_order = 4
					and level1_code = 'ALL'
					and level2_code = 'ALL'

				if @p_id_type = 'EA'
				begin
					select @p_assigned_to_employee_id = @p_id_code 
				end

				if isnull(@p_assigned_to_employee_id,'') = ''	
				begin
					select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Invalid Assignee'
				return
				end 

				update ancillary_request_workflow_assignment
				set current_assignee_ind = 0
  				where company_id = @i_client_id
					and country_code = @i_country_code
					and request_ref_no = @i_request_ref_no
					and current_assignee_ind = 1
				
				if @@ROWCOUNT = 0
				begin
					select @o_childproc_execution_status = 'FAILURE',
 							@o_childproc_execution_error_message = 'Failed insert into Ancillary workflow assignment'
					return
				end

				insert ancillary_request_workflow_assignment
				(
					company_id,
					country_code,
					request_ref_no,
					resource_emp_id,
					assigned_on_date,
					current_assignee_ind,
					last_update_id
				)
				select @i_client_id, @i_country_code, @i_request_ref_no,
						@p_assigned_to_employee_id, SYSDATETIMEOFFSET(),
						1, @i_user_id

				if @@ROWCOUNT = 0
				begin
					select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary Workflow Assignment'
					return
				end

			end

			if @p_to_wf_stage_no = 3 and @p_to_wf_status = 'AP'
			begin

				update ancillary_request_workflow_assignment
				set current_assignee_ind = 0
  				where company_id = @i_client_id
					and country_code = @i_country_code
					and request_ref_no = @i_request_ref_no
					and current_assignee_ind = 1
				
				if @@ROWCOUNT = 0
				begin
					select @o_childproc_execution_status = 'FAILURE',
 							@o_childproc_execution_error_message = 'Failed insert into Ancillary workflow assignment'
					return
				end

			end

			update ancillary_request_register	
			set request_wf_stage_no = @p_to_wf_stage_no,
				request_status = @p_to_wf_status,
				last_update_id = @i_user_id
			where company_id = @i_client_id
				and country_code = @i_country_code
				and request_ref_no = @i_request_ref_no


			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed updating ancillary register'
				return
			end
	
			set @p_event_date = SYSDATETIMEOFFSET()
					
			insert ancillary_request_status_event_log
			(
				company_id, country_code, request_ref_no,
				channel_id,
				eventverb_id,
				from_wf_stage_no,
				to_wf_stage_no,
				event_date, to_status, from_status,
				by_employee_id, 
				to_employee_id_string,
				comments, 
				reason_code,
				last_update_id
			)
			select @i_client_id, @i_country_code, @i_request_ref_no,
					@i_channel_id,
					@i_wfeventverb_id,
					@p_from_wf_stage_no,
					@p_to_wf_stage_no,
					@p_event_date, 
					@p_to_wf_status, @p_from_wf_status,
					@i_by_employee_id, 
					@p_assigned_to_employee_id,
					case @i_comments when '' then null else @i_comments end,
					case @i_reason_code when '' then null else @i_reason_code end,
					@i_user_id

			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary Event Log'
				return
			end
		    
		end	
		
		if @i_wfeventverb_id = 'TADAREJECT'
		begin

			update ancillary_request_register	
			set request_wf_stage_no = @p_to_wf_stage_no,
				request_status = @p_to_wf_status,
				last_update_id = @i_user_id
			where company_id = @i_client_id
				and country_code = @i_country_code
				and request_ref_no = @i_request_ref_no


			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed updating ancillary register'
				return
			end
				
			set @p_event_date = SYSDATETIMEOFFSET()
					
			insert ancillary_request_status_event_log
			(
				company_id, country_code, request_ref_no,
				channel_id,
				eventverb_id,
				from_wf_stage_no,
				to_wf_stage_no,
				event_date, to_status, from_status,
				by_employee_id, 
				to_employee_id_string,
				comments, 
				reason_code,
				last_update_id
			)
			select @i_client_id, @i_country_code, @i_request_ref_no,
					@i_channel_id,
					@i_wfeventverb_id,
					@p_from_wf_stage_no,
					@p_to_wf_stage_no,
					@p_event_date, 
					@p_to_wf_status, @p_from_wf_status,
					@i_by_employee_id, 
					@p_assigned_to_employee_id,
					case @i_comments when '' then null else @i_comments end,
					case @i_reason_code when '' then null else @i_reason_code end,
					@i_user_id

			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary Event Log'
				return
			end
		    
			update ancillary_request_workflow_assignment
			set current_assignee_ind = 0
  			where company_id = @i_client_id
				and country_code = @i_country_code
				and request_ref_no = @i_request_ref_no
				and current_assignee_ind = 1
				
			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary workflow assignment'
				return
			end
		end

		if @i_wfeventverb_id = 'TADARETURN'
		begin

			update ancillary_request_register	
			set request_wf_stage_no = @p_to_wf_stage_no,
				request_status = @p_to_wf_status,
				last_update_id = @i_user_id
			where company_id = @i_client_id
				and country_code = @i_country_code
				and request_ref_no = @i_request_ref_no


			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed updating ancillary register'
				return
			end
				
			set @p_event_date = SYSDATETIMEOFFSET()
					
			insert ancillary_request_status_event_log
			(
				company_id, country_code, request_ref_no,
				channel_id,
				eventverb_id,
				from_wf_stage_no,
				to_wf_stage_no,
				event_date, to_status, from_status,
				by_employee_id, 
				to_employee_id_string,
				comments, 
				reason_code,
				last_update_id
			)
			select @i_client_id, @i_country_code, @i_request_ref_no,
					@i_channel_id,
					@i_wfeventverb_id,
					@p_from_wf_stage_no,
					@p_to_wf_stage_no,
					@p_event_date, 
					@p_to_wf_status, @p_from_wf_status,
					@i_by_employee_id, 
					@p_assigned_to_employee_id,
					case @i_comments when '' then null else @i_comments end,
					case @i_reason_code when '' then null else @i_reason_code end,
					@i_user_id

			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary Event Log'
				return
			end
		    
			update ancillary_request_workflow_assignment
			set current_assignee_ind = 0
  			where company_id = @i_client_id
				and country_code = @i_country_code
				and request_ref_no = @i_request_ref_no
				and current_assignee_ind = 1
				
			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary workflow assignment'
				return
			end
		end

		if @i_wfeventverb_id = 'TADACLOSE'
		begin

			update ancillary_request_register	
			set request_wf_stage_no = @p_to_wf_stage_no,
				request_status = @p_to_wf_status,
				last_update_id = @i_user_id
			where company_id = @i_client_id
				and country_code = @i_country_code
				and request_ref_no = @i_request_ref_no


			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed updating ancillary register'
				return
			end
				
			set @p_event_date = SYSDATETIMEOFFSET()
					
			insert ancillary_request_status_event_log
			(
				company_id, country_code, request_ref_no,
				channel_id,
				eventverb_id,
				from_wf_stage_no,
				to_wf_stage_no,
				event_date, to_status, from_status,
				by_employee_id, 
				to_employee_id_string,
				comments, 
				reason_code,
				last_update_id
			)
			select @i_client_id, @i_country_code, @i_request_ref_no,
					@i_channel_id,
					@i_wfeventverb_id,
					@p_from_wf_stage_no,
					@p_to_wf_stage_no,
					@p_event_date, 
					@p_to_wf_status, @p_from_wf_status,
					@i_by_employee_id, 
					@p_assigned_to_employee_id,
					case @i_comments when '' then null else @i_comments end,
					case @i_reason_code when '' then null else @i_reason_code end,
					@i_user_id

			if @@ROWCOUNT = 0
			begin
				select @o_childproc_execution_status = 'FAILURE',
 						@o_childproc_execution_error_message = 'Failed insert into Ancillary Event Log'
				return
			end
		   
		end

		/*Updating udf fields in ancillary register */
		
		update ancillary_request_register
		set udf_char_1 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_char_1')
					when 1 then
						(case isnull((select isnull(x.paramval,'**NULLVALUESENT**') from #input_params x where x.paramname = 'ancillary_request_register_udf_char_1'),'**NOTININPUTPARAM**')
						 when '**NOTININPUTPARAM**' then udf_char_1
						 when '**NULLVALUESENT**' then null
						 else  
							(select paramval from #input_params where paramname = 'ancillary_request_register_udf_char_1')
						  end )
					else null
					end,
			udf_char_2 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_char_2')
					when 1 then
						(case isnull((select isnull(x.paramval,'**NULLVALUESENT**') from #input_params x where x.paramname = 'ancillary_request_register_udf_char_2'),'**NOTININPUTPARAM**')
						 when '**NOTININPUTPARAM**' then udf_char_2
						 when '**NULLVALUESENT**' then null
						 else  
							(select paramval from #input_params where paramname = 'ancillary_request_register_udf_char_2')
						  end )
					else null
					end,
			udf_char_3 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_char_3')
					when 1 then
						(case isnull((select isnull(x.paramval,'**NULLVALUESENT**') from #input_params x where x.paramname = 'ancillary_request_register_udf_char_3'),'**NOTININPUTPARAM**')
						 when '**NOTININPUTPARAM**' then udf_char_3
						 when '**NULLVALUESENT**' then null
						 else  
							(select paramval from #input_params where paramname = 'ancillary_request_register_udf_char_3')
						  end )
					else null
					end,
			udf_char_4 =case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_char_4')
					when 1 then
						(case isnull((select isnull(x.paramval,'**NULLVALUESENT**') from #input_params x where x.paramname = 'ancillary_request_register_udf_char_4'),'**NOTININPUTPARAM**')
						 when '**NOTININPUTPARAM**' then udf_char_4
						 when '**NULLVALUESENT**' then null
						 else  
							(select paramval from #input_params where paramname = 'ancillary_request_register_udf_char_4')
						  end )
					else null
					end,
			udf_float_1=case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_float_1')
					when 1 then
						(case isnull((select isnull(x.paramval,-200000) from #input_params x where x.paramname = 'ancillary_request_register_udf_float_1'),-300000)
						 when -300000 then udf_float_1
						 when -200000 then null
						 else  
							(select cast(paramval as float) from #input_params where paramname = 'ancillary_request_register_udf_float_1')
						  end )
					else null
					end,
			udf_float_2=case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_float_2')
					when 1 then
						(case isnull((select isnull(x.paramval,-200000) from #input_params x where x.paramname = 'ancillary_request_register_udf_float_2'),-300000)
						 when -300000 then udf_float_2
						 when -200000 then null
						 else  
							(select cast(paramval as float) from #input_params where paramname = 'ancillary_request_register_udf_float_2')
						  end )
					else null
					end,
			udf_float_3=case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_float_3')
					when 1 then
						(case isnull((select isnull(x.paramval,-200000) from #input_params x where x.paramname = 'ancillary_request_register_udf_float_3'),-300000)
						 when -300000 then udf_float_3
						 when -200000 then null
						 else  
							(select cast(paramval as float) from #input_params where paramname = 'ancillary_request_register_udf_float_3')
						  end )
					else null
					end,
			udf_float_4 =  case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_float_4')
					when 1 then
						(case isnull((select isnull(x.paramval,-200000) from #input_params x where x.paramname = 'ancillary_request_register_udf_float_4'),-300000)
						 when -300000 then udf_float_4
						 when -200000 then null
						 else  
							(select cast(paramval as float) from #input_params where paramname = 'ancillary_request_register_udf_float_4')
						  end )
					else null
					end,
			udf_bit_1 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_bit_1')
					when 1 then
						(case isnull((select isnull(x.paramval,2) from #input_params x where x.paramname = 'ancillary_request_register_udf_bit_1'),3)
						 when 3 then udf_bit_1
						 when 2 then null
						 else  
							(select cast(paramval as bit) from #input_params where paramname = 'ancillary_request_register_udf_bit_1')
						  end )
					else null
					end,
			udf_bit_2 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_bit_2')
					when 1 then
						(case isnull((select isnull(x.paramval,2) from #input_params x where x.paramname = 'ancillary_request_register_udf_bit_2'),3)
						 when 3 then udf_bit_2
						 when 2 then null
						 else  
							(select cast(paramval as bit) from #input_params where paramname = 'ancillary_request_register_udf_bit_2')
						  end )
					else null
					end,
			udf_bit_3= case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_bit_3')
					when 1 then
						(case isnull((select isnull(x.paramval,2) from #input_params x where x.paramname = 'ancillary_request_register_udf_bit_3'),3)
						 when 3 then udf_bit_3
						 when 2 then null
						 else  
							(select cast(paramval as bit) from #input_params where paramname = 'ancillary_request_register_udf_bit_3')
						  end )
					else null
					end,
			udf_bit_4= case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_bit_4')
					when 1 then
						(case isnull((select isnull(x.paramval,2) from #input_params x where x.paramname = 'ancillary_request_register_udf_bit_4'),3)
						 when 3 then udf_bit_4
						 when 2 then null
						 else  
							(select cast(paramval as bit) from #input_params where paramname = 'ancillary_request_register_udf_bit_4')
						  end )
					else null
					end,
			udf_date_1=	case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_date_1')
					when 1 then
						(case isnull((select isnull(x.paramval,'2') from #input_params x where x.paramname = 'ancillary_request_register_udf_date_1'),'1')
						 when '1' then udf_date_1
						 when '2' then null
						 else  
								 (select CONVERT(datetimeoffset,
								 (select x.paramval from #input_params x where x.paramname = 'ancillary_request_register_udf_date_1')
								+' ' +
								 (select y.paramval from #input_params y where y.paramname = 'ancillary_request_register_udf_date_1_hour')
								 + ':' + 
								 (select z.paramval from #input_params z where z.paramname = 'ancillary_request_register_udf_date_1_minute')
								 +':00',120))
						  end )
					else null
					end,
			udf_date_2 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_date_2')
					when 1 then
						(case isnull((select isnull(x.paramval,'2') from #input_params x where x.paramname = 'ancillary_request_register_udf_date_2'),'1')
						 when '1' then udf_date_2
						 when '2' then null
						 else  
								 (select CONVERT(datetimeoffset,
								 (select x.paramval from #input_params x where x.paramname = 'ancillary_request_register_udf_date_2')
								+' ' +
								 (select y.paramval from #input_params y where y.paramname = 'ancillary_request_register_udf_date_2_hour')
								 + ':' + 
								 (select z.paramval from #input_params z where z.paramname = 'ancillary_request_register_udf_date_2_minute')
								 +':00',120))
						  end )
					else null
					end,
			udf_date_3 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_date_3')
					when 1 then
						(case isnull((select isnull(x.paramval,'2') from #input_params x where x.paramname = 'ancillary_request_register_udf_date_3'),'1')
						 when '1' then udf_date_3
						 when '2' then null
						 else  
								 (select CONVERT(datetimeoffset,
								 (select x.paramval from #input_params x where x.paramname = 'ancillary_request_register_udf_date_3')
								+' ' +
								 (select y.paramval from #input_params y where y.paramname = 'ancillary_request_register_udf_date_3_hour')
								 + ':' + 
								 (select z.paramval from #input_params z where z.paramname = 'ancillary_request_register_udf_date_3_minute')
								 +':00',120))
						  end )
					else null
					end,
			udf_date_4 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_date_4')
					when 1 then
						(case isnull((select isnull(x.paramval,2) from #input_params x where x.paramname = 'ancillary_request_register_udf_date_4'),'1')
						 when '1' then udf_date_4
						 when '2' then null
						 else  
								 (select CONVERT(datetimeoffset,
								 (select x.paramval from #input_params x where x.paramname = 'ancillary_request_register_udf_date_4')
								+' ' +
								 (select y.paramval from #input_params y where y.paramname = 'ancillary_request_register_udf_date_4_hour')
								 + ':' + 
								 (select z.paramval from #input_params z where z.paramname = 'ancillary_request_register_udf_date_4_minute')
								 +':00',120))
						  end )
					else null
					end,
			udf_analysis_code1 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_analysis_code1')
					when 1 then
						(case isnull((select isnull(x.paramval,'**NULLVALUESENT**') from #input_params x where x.paramname = 'ancillary_request_register_udf_analysis_code1'),'**NOTININPUTPARAM**')
						 when '**NOTININPUTPARAM**' then udf_analysis_code1
						 when '**NULLVALUESENT**' then null
						 else  
							(select paramval from #input_params where paramname = 'ancillary_request_register_udf_analysis_code1')
						  end )
					else null
					end,
			udf_analysis_code2 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_analysis_code2')
					when 1 then
						(case isnull((select isnull(x.paramval,'**NULLVALUESENT**') from #input_params x where x.paramname = 'ancillary_request_register_udf_analysis_code2'),'**NOTININPUTPARAM**')
						 when '**NOTININPUTPARAM**' then udf_analysis_code2
						 when '**NULLVALUESENT**' then null
						 else  
							(select paramval from #input_params where paramname = 'ancillary_request_register_udf_analysis_code2')
						  end )
					else null
					end,
			udf_analysis_code3 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_analysis_code3')
					when 1 then
						(case isnull((select isnull(x.paramval,'**NULLVALUESENT**') from #input_params x where x.paramname = 'ancillary_request_register_udf_analysis_code3'),'**NOTININPUTPARAM**')
						 when '**NOTININPUTPARAM**' then udf_analysis_code3
						 when '**NULLVALUESENT**' then null
						 else  
							(select paramval from #input_params where paramname = 'ancillary_request_register_udf_analysis_code3')
						  end )
					else null
					end,
			udf_analysis_code4 = case (select applicable from #applicable_custom_fields
						  where field_type = 'udf_analysis_code4')
					when 1 then
						(case isnull((select isnull(x.paramval,'**NULLVALUESENT**') from #input_params x where x.paramname = 'ancillary_request_register_udf_analysis_code4'),'**NOTININPUTPARAM**')
						 when '**NOTININPUTPARAM**' then udf_analysis_code4
						 when '**NULLVALUESENT**' then null
						 else  
							(select paramval from #input_params where paramname = 'ancillary_request_register_udf_analysis_code4')
						  end )
					else null
					end,
			last_update_id = @p_by_employee_id
		where company_id = @i_client_id
		and country_code = @i_country_code
		and request_ref_no = @i_request_ref_no

		if @@ROWCOUNT = 0
		begin
		select @o_childproc_execution_status = 'FAILURE',
			@o_childproc_execution_error_message = 'Failed updating ancillary register udf fields'
		return
	end   
	  	
	set @o_childproc_execution_status = 'SUCCESS'

    SET NOCOUNT OFF;
END
