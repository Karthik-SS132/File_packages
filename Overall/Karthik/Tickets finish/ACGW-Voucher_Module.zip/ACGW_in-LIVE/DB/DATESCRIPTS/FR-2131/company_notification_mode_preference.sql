IF NOT EXISTS (select 1 from company_notification_mode_preference where company_id = 'acgw' and country_code = 'in' and  notification_event_code IN ('ANC_TADA_CLAIM_SUBMIT','ANC_TADA_CLAIM_REJECT','ANC_TADA_CLAIM_RETURN','ANC_TADA_CLAIM_APPROVE'))

	BEGIN	
		INSERT [dbo].[company_notification_mode_preference] ([company_id], [country_code],[notification_event_code], [notification_mode],[attachment_avl_ind],[notification_template_id],[last_update_id])
		VALUES 
		(N'acgw', N'in', N'ANC_TADA_CLAIM_SUBMIT', N'EMAIL',N'0',N'ANC_TADA_CLAIM_SUBMIT',N'system'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_REJECT', N'EMAIL',N'0',N'ANC_TADA_CLAIM_REJECT',N'system'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_RETURN', N'EMAIL',N'0',N'ANC_TADA_CLAIM_RETURN',N'system'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_APPROVE', N'EMAIL',N'0',N'ANC_TADA_CLAIM_RETURN',N'system')
	END
	GO	


