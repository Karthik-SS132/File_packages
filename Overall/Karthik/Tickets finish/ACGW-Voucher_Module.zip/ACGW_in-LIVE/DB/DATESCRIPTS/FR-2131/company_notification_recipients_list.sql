IF NOT EXISTS (select 1 from company_notification_recipients_list where company_id = 'acgw' and country_code = 'in' and  notification_event_code IN ('ANC_TADA_CLAIM_SUBMIT','ANC_TADA_CLAIM_REJECT','ANC_TADA_CLAIM_RETURN','ANC_TADA_CLAIM_APPROVE'))

	BEGIN	
		INSERT [dbo].[company_notification_recipients_list] ([company_id], [country_code],[notification_event_code],[notification_mode],[recipient_type],
		[id_type],[org_level_no],[last_update_id])
		VALUES 
		(N'acgw', N'in', N'ANC_TADA_CLAIM_SUBMIT', N'EMAIL',N'To',N'AT',N'0',N'acgwadmn'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_REJECT', N'EMAIL',N'To',N'CB',N'0',N'acgwadmn'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_RETURN', N'EMAIL',N'To',N'CB',N'0',N'acgwadmn'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_APPROVE', N'EMAIL',N'To',N'AT',N'0',N'acgwadmn')
	END
	GO	


