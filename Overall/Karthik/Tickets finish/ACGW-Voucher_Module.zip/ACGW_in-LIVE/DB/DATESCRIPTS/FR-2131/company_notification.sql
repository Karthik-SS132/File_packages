IF NOT EXISTS (select 1 from company_notification where company_id = 'acgw' and country_code = 'in' and  notification_event_code IN ('ANC_TADA_CLAIM_SUBMIT','ANC_TADA_CLAIM_REJECT','ANC_TADA_CLAIM_RETURN','ANC_TADA_CLAIM_APPROVE'))

	BEGIN	
		INSERT [dbo].[company_notification] ([company_id], [country_code],[notification_event_code], [description],[active_ind],[last_update_id])
		VALUES 
		(N'acgw', N'in', N'ANC_TADA_CLAIM_SUBMIT', N'Email to Employee for TADA Claim on submit event',N'1',N'system'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_REJECT', N'Email to Employee for TADA Claim on reject event',N'1',N'system'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_RETURN', N'Email to Employee for TADA Claim on return event',N'1',N'system'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_APPROVE', N'Email to Employee for TADA Claim on approve event',N'1',N'system')
	END
	GO	




