delete from code_table where company_id = 'acgw' and country_code = 'in' and code_type ='TADAREASON'

/* INSERT QUERY NO: 1 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAREASON', 'NOTICKET', 'system'
);

/* INSERT QUERY NO: 2 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAREASON', 'NOTTRAINED', 'system'
);

/* INSERT QUERY NO: 3 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAREASON', 'NOASSETCUST', 'system'
);

/* INSERT QUERY NO: 4 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAREASON', 'BUGINPORTAL', 'system'
);

delete from code_table where company_id = 'acgw' and country_code = 'in' and code_type ='TADAGRADE'

/* INSERT QUERY NO: 1 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M03', 'system'
);

/* INSERT QUERY NO: 2 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M04', 'system'
);

/* INSERT QUERY NO: 3 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M05', 'system'
);

/* INSERT QUERY NO: 4 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M06', 'system'
);

/* INSERT QUERY NO: 5 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M07', 'system'
);

/* INSERT QUERY NO: 6 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M08', 'system'
);

/* INSERT QUERY NO: 7 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M09', 'system'
);

/* INSERT QUERY NO: 8 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M10', 'system'
);

/* INSERT QUERY NO: 9 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M11', 'system'
);

/* INSERT QUERY NO: 10 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M12', 'system'
);



delete from code_table where company_id = 'acgw' and country_code = 'in' and code_type ='TADACOSTCENTER'

/* INSERT QUERY NO: 1 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADACOSTCENTER', 'PAM-COSR1000', 'system'
);

/* INSERT QUERY NO: 2 */
INSERT INTO code_table(company_id, country_code, code_type, code, last_update_id)
VALUES
(
'acgw', 'in', 'TADACOSTCENTER', 'APT-713080', 'system'
);
