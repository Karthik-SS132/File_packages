IF NOT EXISTS (select 1 from company_notification_rules where company_id = 'acgw' and country_code = 'in' and  notification_event_code_1 IN ('ANC_TADA_CLAIM_SUBMIT','ANC_TADA_CLAIM_REJECT','ANC_TADA_CLAIM_RETURN','ANC_TADA_CLAIM_APPROVE'))

	BEGIN	
		INSERT [dbo].[company_notification_rules] ([company_id], [country_code],[transaction_type_code],[transaction_subtype_code],[organogram_level_no],[organogram_level_code],[company_location_code],[request_category],[request_type],[request_priority],[attachment_type],[time_interval],[wf_infromto_ind],[in_wf_stage],[in_wf_status],[from_wf_stage],[from_wf_status],[to_wf_stage],[to_wf_status],[notification_event_code_1],[last_update_id])
		VALUES 
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'1',N'WA',N'ANC_TADA_CLAIM_SUBMIT',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'1',N'L1',N'ANC_TADA_CLAIM_REJECT',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'1',N'L2',N'ANC_TADA_CLAIM_REJECT',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'1',N'L3',N'ANC_TADA_CLAIM_REJECT',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'1',N'L4',N'ANC_TADA_CLAIM_REJECT',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'1',N'R1',N'ANC_TADA_CLAIM_RETURN',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'1',N'R2',N'ANC_TADA_CLAIM_RETURN',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'1',N'R3',N'ANC_TADA_CLAIM_RETURN',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'1',N'R4',N'ANC_TADA_CLAIM_RETURN',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'2',N'A1',N'ANC_TADA_CLAIM_APPROVE',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'2',N'A2',N'ANC_TADA_CLAIM_APPROVE',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'2',N'A3',N'ANC_TADA_CLAIM_APPROVE',N'system'),
		(N'acgw',N'in',N'ANCILLARY',N'ANCILLARY',N'ALL',N'ALL',N'ALL',N'TADA',N'ALL',N'ALL',N'W',N'0',N'FT',N'NA',N'NA',N'NA',N'NA',N'3',N'AP',N'ANC_TADA_CLAIM_APPROVE',N'system')
		
	END
	GO	

