delete from code_table_mlingual_translation where company_id = 'acgw' and country_code = 'in' and code_type ='TADAREASON'

/* INSERT QUERY NO: 1 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAREASON', 'NOTICKET', 'ALL', 'Training not completed', 'Training not completed by Engineer', 'system'
);

/* INSERT QUERY NO: 2 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAREASON', 'NOTTRAINED', 'ALL', 'Ticket not created', 'Ticket not created by coordinator', 'system'
);

/* INSERT QUERY NO: 3 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAREASON', 'NOASSETCUST', 'ALL', 'Not updated by Backoffice', 'Machine/Customer Master not updated by Backoffice', 'system'
);

/* INSERT QUERY NO: 4 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAREASON', 'BUGINPORTAL', 'ALL', 'Bug/Issue in the Application', 'Bug/Issue in the Application', 'system'
);

delete from code_table_mlingual_translation where company_id = 'acgw' and country_code = 'in' and code_type ='TADAGRADE'

/* INSERT QUERY NO: 1 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M03', 'ALL', 'M03', 'M03', 'system'
);


/* INSERT QUERY NO: 2 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M04', 'ALL', 'M04', 'M04', 'system'
);


/* INSERT QUERY NO: 3 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M05', 'ALL', 'M05', 'M05', 'system'
);


/* INSERT QUERY NO: 4 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M06', 'ALL', 'M06', 'M06', 'system'
);


/* INSERT QUERY NO: 5 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M07', 'ALL', 'M07', 'M07', 'system'
);


/* INSERT QUERY NO: 6 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M08', 'ALL', 'M08', 'M08', 'system'
);


/* INSERT QUERY NO: 7 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M09', 'ALL', 'M09', 'M09', 'system'
);


/* INSERT QUERY NO: 8 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M10', 'ALL', 'M10', 'M10', 'system'
);


/* INSERT QUERY NO: 9 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M11', 'ALL', 'M11', 'M11', 'system'
);


/* INSERT QUERY NO: 10 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADAGRADE', 'M12', 'ALL', 'M12', 'M12', 'system'
);

delete from code_table_mlingual_translation where company_id = 'acgw' and country_code = 'in' and code_type ='TADACOSTCENTER'

/* INSERT QUERY NO: 1 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADACOSTCENTER', 'PAM-COSR1000', 'ALL', 'PAM-COSR1000', 'PAM-COSR1000', 'system'
);


/* INSERT QUERY NO: 2 */
INSERT INTO code_table_mlingual_translation(company_id, country_code, code_type, code, locale_id, short_description, long_description, last_update_id)
VALUES
(
'acgw', 'in', 'TADACOSTCENTER', 'APT-713080', 'ALL', 'APT-713080', 'APT-713080', 'system'
);

