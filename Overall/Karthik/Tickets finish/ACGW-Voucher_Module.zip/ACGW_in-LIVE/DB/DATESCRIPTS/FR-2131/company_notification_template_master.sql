IF NOT EXISTS (select 1 from company_notification_template_master where company_id = 'acgw' and country_code = 'in' and  notification_template_id IN ('ANC_TADA_CLAIM_SUBMIT','ANC_TADA_CLAIM_REJECT','ANC_TADA_CLAIM_RETURN','ANC_TADA_CLAIM_APPROVE'))

	BEGIN	
		INSERT [dbo].[company_notification_template_master] ([company_id], [country_code],[notification_template_id], [description],[last_update_id])
		VALUES 
		(N'acgw', N'in', N'ANC_TADA_CLAIM_SUBMIT', N'Tada Claim Submit Notification',N'system'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_REJECT', N'Tada Claim Reject Notification',N'system'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_RETURN', N'Tada Claim Return Notification',N'system'),
		(N'acgw', N'in', N'ANC_TADA_CLAIM_APPROVE', N'Tada Claim Approve Notification',N'system')
	END
	GO	


