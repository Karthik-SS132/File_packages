/****** Object:  StoredProcedure [dbo].[sp_retrieve_manage_custom_info_list_asset_id_code]    Script Date: 2/22/2022 11:50:41 AM ******/
IF EXISTS(SELECT 1 FROM SYS.PROCEDURES WHERE NAME = 'sp_retrieve_manage_custom_info_list_asset_id_code')
BEGIN
	DROP PROCEDURE [dbo].[sp_retrieve_manage_custom_info_list_asset_id_code]
END
GO

/****** Object:  StoredProcedure [dbo].[sp_retrieve_manage_custom_info_list_asset_id_code]    Script Date: 2/22/2022 11:50:41 AM ******/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_retrieve_manage_custom_info_list_asset_id_code] 
    @i_client_id [uddt_client_id], 
    @i_country_code [uddt_country_code], 
    @i_session_id [sessionid], 
    @i_user_id [userid], 
    @i_locale_id [uddt_locale_id], 
    @i_custom_info_code [uddt_varchar_60], 
    @i_inputparam_xml [uddt_nvarchar_max], 
    @o_retrieve_status [uddt_varchar_5] OUTPUT
AS
BEGIN

	create table #inputparams 
	(
		paramname varchar(50) not null,
		paramval varchar(50) null
	)

	if (@i_inputparam_xml = '') 
	begin 
		set @i_inputparam_xml = '{}' 
	end

	insert #inputparams 
	(
		paramname, 
		paramval
	)
	select [key], [value]
	from openjson(@i_inputparam_xml)

	update #inputparams
	set paramval = null 
	where paramval = 'ALL'
		or paramval = ''

	select '' as custom_info_list,
		'{' +
			'"code":"' + a.asset_id + '",' +
			'"description":"' + a.asset_id + '",' +
			'"asset_status":"' + a.asset_status + '",' +
			'"equipment_id":"' + b.equipment_id + '",' +
			'"asset_loc_code":"' + a.asset_location_code + '",' +
			'"country_code":"' + a.country_code + '",' +
			'"state_code":"' + isnull(a.asset_location_state_code ,'')+ '",' +
			'"district_code":"' +isnull(a.asset_location_district_code,'')+ '",' +
			'"customer_id":"' + a.customer_id + '"' +
		'}'
	as o_custom_info_json
	from asset_master a, equipment b
	where a.country_code = @i_country_code
		and a.company_id = @i_client_id
		and a.company_id = b.company_id
		and a.country_code = b.country_code
		and a.equipment_id = b.equipment_id
		and a.asset_status = 'A'
	
	select @o_retrieve_status = 'SP001'

    SET NOCOUNT OFF;
END
