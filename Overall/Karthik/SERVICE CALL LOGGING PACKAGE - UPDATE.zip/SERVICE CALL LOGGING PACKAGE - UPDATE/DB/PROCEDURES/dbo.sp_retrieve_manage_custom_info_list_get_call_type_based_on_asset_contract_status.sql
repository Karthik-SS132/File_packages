/****** Object:  StoredProcedure [dbo].[sp_retrieve_manage_custom_info_list_get_call_type_based_on_asset_contract_status]    Script Date: 2/22/2022 11:50:41 AM ******/
IF EXISTS(SELECT 1 FROM SYS.PROCEDURES WHERE NAME = 'sp_retrieve_manage_custom_info_list_get_call_type_based_on_asset_contract_status')
BEGIN
	DROP PROCEDURE [dbo].[sp_retrieve_manage_custom_info_list_get_call_type_based_on_asset_contract_status]
END
GO

/****** Object:  StoredProcedure [dbo].[sp_retrieve_manage_custom_info_list_get_call_type_based_on_asset_contract_status]    Script Date: 2/22/2022 11:50:41 AM ******/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_retrieve_manage_custom_info_list_get_call_type_based_on_asset_contract_status] 
    @i_client_id [uddt_client_id], 
    @i_country_code [uddt_country_code], 
    @i_session_id [sessionid], 
    @i_user_id [userid], 
    @i_locale_id [uddt_locale_id], 
    @i_custom_info_code [uddt_varchar_60], 
    @i_inputparam_xml [uddt_nvarchar_max], 
    @o_retrieve_status [uddt_varchar_5] OUTPUT
AS
BEGIN

	declare @p_asset_id nvarchar(30)

	create table #inputparams 
	(
		paramname varchar(50) not null,
		paramval varchar(50) null
	)


	if (@i_inputparam_xml = '') 
	begin 
		set @i_inputparam_xml = '{}' 
	end

	insert #inputparams 
	(
		paramname, 
		paramval
	)
	select [key], [value]
	from openjson(@i_inputparam_xml)

	update #inputparams
	set paramval = null 
	where paramval = 'ALL'
		or paramval = ''

	select '' as custom_info_list,
		'{' +
			'"code":"' + a.type_code_value + '",' +
			'"description":"' + dbo.code_description (@i_client_id, @i_country_code, @i_locale_id, 'CALLTYPE', a.type_code_value) + '",' +
			'"asset_id":"' + b.asset_id + '"' +
		'}'
	as o_custom_info_json
	from category_type_link a, asset_master b, asset_service_contract c
	where a.company_id = @i_client_id
		and a.country_code = @i_country_code
		and a.company_id = b.company_id
		and a.country_code = b.country_code
		and a.company_id = c.company_id
		and a.country_code = c.country_code
		and b.asset_id = c.asset_id
		and b.installation_date is not null
		and a.link_type = 'AS'
		and a.category_code_value = c.contract_type
		and SYSDATETIMEOFFSET() between c.effective_from_date and c.effective_to_date
	union
	select '' as custom_info_list,
		'{' +
			'"code":"' + a.type_code_value + '",' +
			'"description":"' + dbo.code_description (@i_client_id, @i_country_code, @i_locale_id, 'CALLTYPE', a.type_code_value) + '",' +
			'"asset_id":"' + b.asset_id + '"' +
		'}'
	as o_custom_info_json
	from category_type_link a, asset_master b
	where a.company_id = @i_client_id
		and a.country_code = @i_country_code
		and a.company_id = b.company_id
		and a.country_code = b.country_code
		and b.installation_date is null
		and a.link_type = 'AS'
		and a.category_code_value = 'NC'
	union
	select '' as custom_info_list,
		'{' +
			'"code":"' + a.type_code_value + '",' +
			'"description":"' + dbo.code_description (@i_client_id, @i_country_code, @i_locale_id, 'CALLTYPE', a.type_code_value) + '",' +
			'"asset_id":"' + b.asset_id + '"' +
		'}'
	as o_custom_info_json
	from category_type_link a, asset_master b
	where a.company_id = @i_client_id
		and a.country_code = @i_country_code
		and a.company_id = b.company_id
		and a.country_code = b.country_code
		and b.installation_date is not null
		and a.link_type = 'AS'
		and a.category_code_value = 'OW'
		and b.asset_id not in (select a.asset_id from asset_master a, asset_service_contract b
								where a.company_id = @i_client_id
									and a.country_code = @i_country_code
									and a.company_id = b.company_id
									and a.country_code = b.country_code
									and a.asset_id = b.asset_id
									and a.installation_date is not null
									and SYSDATETIMEOFFSET() between b.effective_from_date and b.effective_to_date)

	select @o_retrieve_status = 'SP001'

    SET NOCOUNT OFF;
	
END