/****** Object:  StoredProcedure [dbo].[sp_save_manage_custom_info_service_call_logging]    Script Date: 15/03/2023 11:21:41 AM ******/
IF EXISTS(SELECT 1 FROM SYS.PROCEDURES WHERE NAME = 'sp_save_manage_custom_info_service_call_logging')
BEGIN
	DROP PROCEDURE [dbo].[sp_save_manage_custom_info_service_call_logging]
END
GO

/****** Object:  StoredProcedure [dbo].[sp_save_manage_custom_info_service_call_logging]    Script Date: 15-03-2023 11:21:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_save_manage_custom_info_service_call_logging] 
   @i_session_id [sessionid], 
    @i_user_id [userid], 
    @i_client_id [uddt_client_id], 
    @i_locale_id [uddt_locale_id], 
    @i_country_code [uddt_country_code], 
    @i_custom_info_code [uddt_varchar_60], 
    @i_custom_info_ref_no1 [uddt_nvarchar_60], 
    @i_custom_info_ref_no2 [uddt_nvarchar_60], 
    @i_inputparam_header_xml [uddt_nvarchar_max], 
    @i_rec_timestamp [uddt_uid_timestamp], 
    @i_save_mode [uddt_varchar_1],
	@o_outputparam_detail_xml [uddt_nvarchar_max] OUTPUT,  
    @o_update_status [uddt_varchar_5] OUTPUT, 
	@custom_info_detail [sp_save_manage_custom_info_custom_info_detail] READONLY,
    @i_error_msg [uddt_nvarchar_max] OUTPUT
AS
BEGIN
	
	/* MODIFY THE INPUT HEADER TO ADD THE LAST ACCESS INFO */
	select @i_inputparam_header_xml = json_modify(@i_inputparam_header_xml, '$.screen_id', 'service_call_logging')
	select @i_inputparam_header_xml = json_modify(@i_inputparam_header_xml, '$.screen_name', 'Job Logging - Mobile')
	select @i_inputparam_header_xml = json_modify(@i_inputparam_header_xml, '$.allow_new_txn', '0')
	select @i_inputparam_header_xml = json_modify(@i_inputparam_header_xml, '$.modify_last_access', '1')	
	

	/* DECLARE THE PROGRAM VARIABLES */
	declare	@p_sysdatetimeoffset datetimeoffset(7),
		@p_transaction_type varchar(20),
		@p_transaction_ref_no varchar(30),
		@p_file_category varchar(2),
		@p_file_type varchar(2),
		@p_file_name nvarchar(60),
		@p_file_path nvarchar(60),
		@p_file_extension varchar(10),
		@p_closure_report_indicator bit,
		@p_screen_id varchar(30), 
		@p_screen_name varchar(30), 
		@p_allow_new_txn bit,		
		@p_modify_last_access bit,
		@p_event_date varchar(10),
		@p_event_hour varchar(2),
		@p_event_minute varchar(2),
		@p_service_update_status varchar(10),
		@p_service_call_ref_no nvarchar(30),
		@p_service_error_nof_no nvarchar(30),
		@p_event_second varchar(2),
		@p_feature_id varchar(15),
		@p_asset_id nvarchar(30),
		@p_asset_location_code nvarchar(100),
		@p_equipment_id nvarchar(30),
		@p_call_category nvarchar(15),
		@p_call_type nvarchar(10),
		@p_equipment_category nvarchar(15),
		@p_equipment_type nvarchar(15),
		@p_customer_id nvarchar(100),
		@p_customer_location_code varchar(10),
		@p_customer_contact_name nvarchar(60),
		@p_customer_contact_mobile_no nvarchar(20),
		@p_customer_contact_email_id nvarchar(60), 
		@p_organogram_level_no tinyint, 
		@p_organogram_level_code nvarchar(15),
		@p_company_location_code nvarchar(8),
		@p_by_employee_id nvarchar(12),
		@p_service_error_no varchar(10),
		@p_call_inputparam nvarchar(max),
		@p_problem_desc nvarchar(500),
		@p_assign_to_emp_id nvarchar(12),
		@p_visit_date varchar(10)

	/* ASSIGN THE VALUES TO THE DECLARED VARIABLES */
	select @p_sysdatetimeoffset = dbo.fn_sysdatetimeoffset
	(
		@i_client_id, 
		@i_country_code, 
		@i_user_id
	)
	
	select @p_transaction_type = json_value(@i_inputparam_header_xml, '$.transaction_type')
	select @p_transaction_ref_no = json_value(@i_inputparam_header_xml, '$.transaction_ref_no')
	select @p_file_category = json_value(@i_inputparam_header_xml, '$.file_category')
	select @p_file_type = json_value(@i_inputparam_header_xml, '$.file_type')
	select @p_file_name = json_value(@i_inputparam_header_xml, '$.file_name')
	select @p_file_path = json_value(@i_inputparam_header_xml, '$.file_path')
	select @p_closure_report_indicator = convert(bit, isnull(json_value(@i_inputparam_header_xml, '$.closure_report_indicator'), ''))
	select @p_screen_id = json_value(@i_inputparam_header_xml, '$.screen_id')
	select @p_screen_name = json_value(@i_inputparam_header_xml, '$.screen_name')
	select @p_allow_new_txn = convert(bit, isnull(json_value(@i_inputparam_header_xml, '$.allow_new_txn'), ''))
	select @p_modify_last_access = convert(bit, isnull(json_value(@i_inputparam_header_xml, '$.modify_last_access'), ''))
	select @p_event_date = json_value(@i_inputparam_header_xml, '$.event_date')
	select @p_event_hour = json_value(@i_inputparam_header_xml, '$.event_hour')
	select @p_event_minute = json_value(@i_inputparam_header_xml, '$.event_minute')
	select @p_event_second = json_value(@i_inputparam_header_xml, '$.event_second')
	select @p_call_category = json_value(@i_inputparam_header_xml, '$.call_category')
	select @p_call_type = json_value(@i_inputparam_header_xml, '$.call_type')
	select @p_asset_id = json_value(@i_inputparam_header_xml, '$.asset_id')
	select @p_equipment_id = json_value(@i_inputparam_header_xml, '$.equipment_id')
	select @p_customer_id = json_value(@i_inputparam_header_xml, '$.customer_id')
	select @p_customer_location_code = json_value(@i_inputparam_header_xml, '$.customer_location_code')
	select @p_customer_contact_name = json_value(@i_inputparam_header_xml, '$.customer_details.customer_name')
	select @p_customer_contact_email_id = json_value(@i_inputparam_header_xml, '$.customer_details.customer_email_id')
	select @p_customer_contact_mobile_no = json_value(@i_inputparam_header_xml, '$.customer_details.customer_mobile_no')
	select @p_problem_desc = json_value(@i_inputparam_header_xml, '$.customer_req')
	select @p_assign_to_emp_id = json_value(@i_inputparam_header_xml, '$.assign_to_emp_id')
	select @p_visit_date = json_value(@i_inputparam_header_xml, '$.visit_date')
	
	select @p_by_employee_id = employee_id
	from users
	where company_id = @i_client_id
	  and country_code = @i_country_code
	  and user_id = @i_user_id

	select @p_call_inputparam = '<inputparam><channel>mobile</channel></inputparam>'

	set @p_service_call_ref_no = ''

	execute sp_save_manage_call_register @i_client_id, @i_country_code, @i_session_id, @i_user_id, @i_locale_id, 
		@p_customer_id, @p_asset_id, @p_customer_contact_email_id, @p_equipment_id, @p_problem_desc, 'MED', @i_user_id,
		@p_event_date, @p_event_hour, @p_event_minute, @p_customer_location_code, 2, 'Service', @p_call_category,
		@p_call_type, '', 'HO', @p_customer_contact_name, '', @p_customer_contact_email_id, 'NB',
		0,0,0,0,'INR','','', '','', @p_call_inputparam, 'A','00000000-0000-0000-0000-000000000000',
		@p_service_update_status OUTPUT, @p_service_call_ref_no OUTPUT, @p_service_error_no OUTPUT

	set @o_update_status = 'SP001'
				
END


