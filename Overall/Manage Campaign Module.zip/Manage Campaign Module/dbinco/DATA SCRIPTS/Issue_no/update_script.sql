update functional_access_profile 
set feature_access = '1' 
where company_id = 'dbinco'
	and country_code = 'in'
	and feature_id ='CUSTFB' 
	and user_group_id = 'CCENTRUSER'

update functional_access_profile 
set feature_access = '0' 
where company_id = 'dbinco'
	and country_code = 'in'
	and feature_id ='CUSTFB' 
	and user_group_id = 'DLR-SECORD'
	
update functional_access_profile 
set feature_access = '1' 
where company_id = 'dbinco'
	and country_code = 'in'
	and feature_id ='DOCSTORE' 
	and user_group_id = 'DLR-SECORD'
	