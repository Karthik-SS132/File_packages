delete from code_table_mlingual_translation where company_id = 'dbinco' and country_code = 'in' and code_type = 'CAMPAIGNCATG'

INSERT [dbo].[code_table_mlingual_translation] ([company_id], [country_code], [code_type], [code], [locale_id], [short_description], [long_description], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNCATG', N'SALES', N'ALL', N'Sales', N'Sales', N'system')

INSERT [dbo].[code_table_mlingual_translation] ([company_id], [country_code], [code_type], [code], [locale_id], [short_description], [long_description], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNCATG', N'SERVICE', N'ALL', N'Service', N'Service', N'system')


delete from code_table_mlingual_translation where company_id = 'dbinco' and country_code = 'in' and code_type = 'CAMPAIGNTYPE'

INSERT [dbo].[code_table_mlingual_translation] ([company_id], [country_code], [code_type], [code], [locale_id], [short_description], [long_description], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNTYPE', N'ONLINE', N'ALL', N'Online', N'Online', N'system')

INSERT [dbo].[code_table_mlingual_translation] ([company_id], [country_code], [code_type], [code], [locale_id], [short_description], [long_description], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNTYPE', N'WTYEXPIRY', N'ALL', N'Warranty Expiry', N'Warranty Expiry', N'system')
