delete from workflow_status_master where company_id = 'dbinco' and country_code = 'in' and transaction_type_code ='CAMPAIGN'

/* INSERT QUERY NO: 1 */
INSERT INTO workflow_status_master(company_id, country_code, transaction_type_code, request_category, status_code, first_status_ind, last_status_ind, last_update_id)
VALUES
(
'dbinco', 'in', 'CAMPAIGN', 'ALL', 'AP', 0, 0, 'system'
);

/* INSERT QUERY NO: 2 */
INSERT INTO workflow_status_master(company_id, country_code, transaction_type_code, request_category, status_code, first_status_ind, last_status_ind, last_update_id)
VALUES
(
'dbinco', 'in', 'CAMPAIGN', 'ALL', 'CO', 0, 1, 'system'
);

/* INSERT QUERY NO: 3 */
INSERT INTO workflow_status_master(company_id, country_code, transaction_type_code, request_category, status_code, first_status_ind, last_status_ind, last_update_id)
VALUES
(
'dbinco', 'in', 'CAMPAIGN', 'ALL', 'IP', 0, 0, 'system'
);

/* INSERT QUERY NO: 4 */
INSERT INTO workflow_status_master(company_id, country_code, transaction_type_code, request_category, status_code, first_status_ind, last_status_ind, last_update_id)
VALUES
(
'dbinco', 'in', 'CAMPAIGN', 'ALL', 'OP', 1, 0, 'system'
);

/* INSERT QUERY NO: 5 */
INSERT INTO workflow_status_master(company_id, country_code, transaction_type_code, request_category, status_code, first_status_ind, last_status_ind, last_update_id)
VALUES
(
'dbinco', 'in', 'CAMPAIGN', 'ALL', 'RV', 0, 0, 'system'
);
