delete from package_feature 
where feature_id in ('CAMPREG')

insert into package_feature (package_id, module_id, feature_id, last_update_id)
select 'DREAMS','BASICMASTER','CAMPREG','system'


