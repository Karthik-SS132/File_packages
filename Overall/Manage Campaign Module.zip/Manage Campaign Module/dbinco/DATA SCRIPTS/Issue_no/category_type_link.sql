
DELETE FROM [dbo].[category_type_link] WHERE [company_id] = N'dbinco' AND [country_code] = N'in' AND [link_type] = 'CR'

INSERT [dbo].[category_type_link] ([company_id], [country_code], [link_type], [category_code_type], [category_code_value], [type_code_type], [type_code_value], [last_update_id]) 
VALUES (N'dbinco', N'in', N'CR', N'CAMPAIGNCATG', N'SALES', N'CAMPAIGNTYPE', N'ONLINE', N'system')

INSERT [dbo].[category_type_link] ([company_id], [country_code], [link_type], [category_code_type], [category_code_value], [type_code_type], [type_code_value], [last_update_id]) 
VALUES (N'dbinco', N'in', N'CR', N'CAMPAIGNCATG', N'SERVICE', N'CAMPAIGNTYPE', N'WTYEXPIRY', N'system')

