delete from workflow_status_link where company_id = 'dbinco' and country_code = 'in' and transaction_type_code = 'CAMPAIGN' 


/* INSERT QUERY NO: 1 */
INSERT INTO workflow_status_link(company_id, country_code, transaction_type_code, request_category, request_type, from_workflow_stage, from_status, to_workflow_stage, to_status, lcl_value, ucl_value, last_update_id)
VALUES
(
'dbinco', 'in', 'CAMPAIGN', 'ALL', 'ALL', 1, 'OP', 2, 'RV', 'NA','NA',  'system'
);

/* INSERT QUERY NO: 2 */
INSERT INTO workflow_status_link(company_id, country_code, transaction_type_code, request_category, request_type, from_workflow_stage, from_status, to_workflow_stage, to_status, lcl_value, ucl_value, last_update_id)
VALUES
(
'dbinco', 'in', 'CAMPAIGN', 'ALL', 'ALL', 2, 'RV', 3, 'AP', 'NA','NA',  'system'
);

/* INSERT QUERY NO: 3 */
INSERT INTO workflow_status_link(company_id, country_code, transaction_type_code, request_category, request_type, from_workflow_stage, from_status, to_workflow_stage, to_status, lcl_value, ucl_value, last_update_id)
VALUES
(
'dbinco', 'in', 'CAMPAIGN', 'ALL', 'ALL', 3, 'AP', 3, 'IP', 'NA','NA',  'system'
);


/* INSERT QUERY NO: 4 */
INSERT INTO workflow_status_link(company_id, country_code, transaction_type_code, request_category, request_type, from_workflow_stage, from_status, to_workflow_stage, to_status, lcl_value, ucl_value, last_update_id)
VALUES
(
'dbinco', 'in', 'CAMPAIGN', 'ALL', 'ALL', 3, 'IP', 4, 'CO', 'NA','NA',  'system'
);
