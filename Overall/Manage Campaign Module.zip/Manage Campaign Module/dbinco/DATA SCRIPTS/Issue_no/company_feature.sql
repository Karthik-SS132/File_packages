DELETE FROM [dbo].[company_feature] WHERE [company_id] = N'dbinco' AND [country_code] = N'in' AND [feature_id] IN (N'CAMPAIGNAPPROVE')
 
INSERT [dbo].[company_feature] ([company_id], [country_code], [feature_id], [feature_name], [feature_display_label], [program_reference], [menu_display_ind], [screen_id], [channel_id], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNAPPROVE', N'Approve', N'Approve', NULL, 0, N'CAMPAIGNAPPROVE', N'web', N'system')

DELETE FROM [dbo].[company_feature] WHERE [company_id] = N'dbinco' AND [country_code] = N'in' AND [feature_id] IN (N'CAMPAIGNCO')
 
INSERT [dbo].[company_feature] ([company_id], [country_code], [feature_id], [feature_name], [feature_display_label], [program_reference], [menu_display_ind], [screen_id], [channel_id], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNCO', N'Complete', N'Complete', NULL, 0, N'CAMPAIGNCOMPLETE', N'web', N'system')

DELETE FROM [dbo].[company_feature] WHERE [company_id] = N'dbinco' AND [country_code] = N'in' AND [feature_id] IN (N'CAMPAIGNREVIEW')
 
INSERT [dbo].[company_feature] ([company_id], [country_code], [feature_id], [feature_name], [feature_display_label], [program_reference], [menu_display_ind], [screen_id], [channel_id], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNREVIEW', N'Submit for Review', N'Submit for Review', NULL, 0, N'CAMPAIGNREVIEW', N'web', N'system')

DELETE FROM [dbo].[company_feature] WHERE [company_id] = N'dbinco' AND [country_code] = N'in' AND [feature_id] IN (N'CAMPREG')
 
INSERT [dbo].[company_feature] ([company_id], [country_code], [feature_id], [feature_name], [feature_display_label], [program_reference], [menu_display_ind], [screen_id], [channel_id], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPREG', N'Campaign Register', N'Campaign Register', NULL, 1, N'manage_campaign_register', N'web', N'system')

DELETE FROM [dbo].[company_feature] WHERE [company_id] = N'dbinco' AND [country_code] = N'in' AND [feature_id] IN (N'CAMPREGDETAIL')
 
INSERT [dbo].[company_feature] ([company_id], [country_code], [feature_id], [feature_name], [feature_display_label], [program_reference], [menu_display_ind], [screen_id], [channel_id], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPREGDETAIL', N'Campaign Register Detail', N'Campaign Register Detail', NULL, 0, N'manage_campaign_register_edit', N'web', N'system')