delete from code_table where company_id = 'dbinco' and country_code = 'in' and code_type = 'CAMPAIGNCATG'

INSERT [dbo].[code_table] ([company_id], [country_code], [code_type], [code], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNCATG', N'SALES', N'system')

INSERT [dbo].[code_table] ([company_id], [country_code], [code_type], [code], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNCATG', N'SERVICE', N'system')


delete from code_table where company_id = 'dbinco' and country_code = 'in' and code_type = 'CAMPAIGNTYPE'

INSERT [dbo].[code_table] ([company_id], [country_code], [code_type], [code], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNTYPE', N'ONLINE', N'system')

INSERT [dbo].[code_table] ([company_id], [country_code], [code_type], [code], [last_update_id]) VALUES (N'dbinco', N'in', N'CAMPAIGNTYPE', N'WTYEXPIRY', N'system')

